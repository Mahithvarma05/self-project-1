package com.backendservice.digital_receipt_system.dto;

import java.math.BigDecimal;
import java.time.Instant;

public record BillingStatusDto(
        String status,
        BigDecimal amount,
        Long stampId,
        Instant expiresAt
) {}
