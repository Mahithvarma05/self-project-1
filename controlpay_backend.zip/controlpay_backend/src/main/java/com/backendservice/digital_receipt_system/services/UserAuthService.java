package com.backendservice.digital_receipt_system.services;

import com.backendservice.digital_receipt_system.dto.request.UserLoginRequest;
import com.backendservice.digital_receipt_system.dto.response.UserLoginResponse;
import com.backendservice.digital_receipt_system.entities.User;
import com.backendservice.digital_receipt_system.exceptions.InvalidCredentialsException;
import com.backendservice.digital_receipt_system.exceptions.StoreNotMappedException;
import com.backendservice.digital_receipt_system.repositories.UserRepository;
import com.backendservice.digital_receipt_system.repositories.UserStoreMapRepository;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UserAuthService {

    private final UserRepository userRepo;
    private final UserStoreMapRepository mapRepo;

    public UserAuthService(UserRepository userRepo, UserStoreMapRepository mapRepo) {
        this.userRepo = userRepo;
        this.mapRepo = mapRepo;
    }

    @Transactional(readOnly = true)
    public UserLoginResponse login(UserLoginRequest req) {

        User user = userRepo.findByMobileNumber(req.getMobileNumber())
                .orElseThrow(InvalidCredentialsException::new);

        if (!BCrypt.checkpw(req.getPassword(), user.getPassword())) {
            throw new InvalidCredentialsException();
        }

        String gstin = mapRepo.findStoreForUser(user.getId())
                .orElseThrow(StoreNotMappedException::new);

        return new UserLoginResponse(
                user.getId(), user.getName(), user.getRole(), gstin,
                user.getSseKey()
        );
    }
}
