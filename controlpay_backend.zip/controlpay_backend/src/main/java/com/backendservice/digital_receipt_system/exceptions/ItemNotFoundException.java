package com.backendservice.digital_receipt_system.exceptions;

public class ItemNotFoundException extends RuntimeException {
    public ItemNotFoundException(String barcode) {
        super("Item not found for barcode: " + barcode);
    }
}