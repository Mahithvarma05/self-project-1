package com.backendservice.digital_receipt_system.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class StartParkingRequest {
    
    @NotBlank
    private String areaCode; // From QR code scan
    
    private Long vehicleId; // If using pre-saved vehicle
    
    // For new vehicle details
    private String vehicleType;
    private String numberPlate;
}