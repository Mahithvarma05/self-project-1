package com.backendservice.digital_receipt_system.controller;

import com.backendservice.digital_receipt_system.dto.StoreDto;
import com.backendservice.digital_receipt_system.dto.request.GstinRequest;
import com.backendservice.digital_receipt_system.services.StoreService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/v1/stores")
@Validated
public class StoreController {

    private final StoreService service;

    public StoreController(StoreService service) {
        this.service = service;
    }

    // POST with JSON body: { "gstin": "29ABCDE1234F1Z5" }
    @PostMapping("/gstin")
    public ResponseEntity<StoreDto> postByGstin(@Valid @RequestBody GstinRequest request) {
        StoreDto dto = service.findByGstin(request.getGstin());
        return ResponseEntity.ok(dto);
    }
}