package com.backendservice.digital_receipt_system.services;

import com.backendservice.digital_receipt_system.dto.BillingItemView;
import com.backendservice.digital_receipt_system.dto.BillingQueueDto;
import com.backendservice.digital_receipt_system.dto.BillingStatusDto;
import com.backendservice.digital_receipt_system.dto.ItemLiteDto;
import com.backendservice.digital_receipt_system.dto.request.BillingItemReq;
import com.backendservice.digital_receipt_system.dto.request.BillingRequestDto;
import com.backendservice.digital_receipt_system.dto.response.BillingResponse;
import com.backendservice.digital_receipt_system.entities.BillingRequest;
import com.backendservice.digital_receipt_system.entities.BillingRequestItem;
import com.backendservice.digital_receipt_system.entities.User;
import com.backendservice.digital_receipt_system.helper.BillingMapper;
import com.backendservice.digital_receipt_system.repositories.*;
import com.backendservice.digital_receipt_system.events.BillingCreatedEvent;
import com.backendservice.digital_receipt_system.events.BillingStatusEvent;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class BillingApprovalService {

    private final BillingRequestRepository billingRepo;
    private final UserRepository userRepo;
    private final ItemRepository itemRepo;
    private final UserStoreMapRepository mapRepo;
    private final BillingApprovalStreamService stream;
//    private final PushService push;
    private final BillingMapper mapper;
    private final BillingRequestItemRepository billingRequestItemRepository;
    private final ApplicationEventPublisher publisher;

    @Transactional
    public BillingResponse requestBillingApproval(BillingRequestDto dto, String key) {

        User customer = userRepo.findBySseKey(key)
                .orElseThrow(() -> new RuntimeException("Invalid key"));

        billingRepo.expireNow(Instant.now());

        Optional<BillingRequest> active =
                billingRepo.findTopByCustomerIdAndGstinAndStatusOrderByExpiresAtDesc(
                        customer.getId(), dto.gstin(), BillingRequest.Status.PENDING);

        if (active.isPresent())
            return new BillingResponse("ALREADY_PENDING", active.get().getId());

        BigDecimal total = BigDecimal.ZERO;
        BigDecimal gst = BigDecimal.ZERO;

        // 🧾 Collect line items (bulk-fetch items to avoid N+1 queries)
        List<BillingRequestItem> itemRows = new ArrayList<>();

        // collect item ids from request
        List<Long> itemIds = dto.items()
                .stream()
                .map(BillingItemReq::itemId)
                .collect(Collectors.toList());

        // fetch required fields as DTOs in one DB call (lighter than full entities)
        Map<Long, ItemLiteDto> itemsById = itemRepo.findAllLiteByIdIn(itemIds)
                .stream()
                .collect(Collectors.toMap(ItemLiteDto::id, Function.identity()));

        for (BillingItemReq i : dto.items()) {
            ItemLiteDto item = itemsById.get(i.itemId());
            if (item == null) {
                throw new RuntimeException("Item not found: " + i.itemId());
            }

            BigDecimal line = item.price().multiply(BigDecimal.valueOf(i.qty()));
            BigDecimal gstLine = line.multiply(item.gstPercentage()).divide(BigDecimal.valueOf(100));
            BigDecimal finalLine = line.add(gstLine);

            total = total.add(line);
            gst = gst.add(gstLine);

            BillingRequestItem row = new BillingRequestItem();
            row.setItemId(item.id());
            row.setItemName(item.name());
            row.setQty(i.qty());
            row.setPrice(item.price());
            row.setGstPercentage(item.gstPercentage());
            row.setLineTotal(finalLine);

            itemRows.add(row);
        }

        BillingRequest r = new BillingRequest();
        r.setCustomerId(customer.getId());
        r.setGstin(dto.gstin());
        r.setTotalAmount(total);
        r.setGstAmount(gst);
        r.setGrandTotal(total.add(gst));
        r.setExpiresAt(Instant.now().plus(30, ChronoUnit.MINUTES));
        r.setStatus(BillingRequest.Status.PENDING);
        billingRepo.save(r);

        // 🔗 Now attach rows to request
        itemRows.forEach(i -> i.setRequest(r));
        billingRequestItemRepository.saveAll(itemRows);

        // prepare lightweight views and agent list for notification event
        List<BillingItemView> items =
                billingRequestItemRepository.findViewsByRequest(r.getId());

        List<Long> agents = mapRepo.findBillingAgentsForStore(r.getGstin());

        // publish AFTER_COMMIT event so notifications happen only if transaction commits
        publisher.publishEvent(new BillingCreatedEvent(
                r.getId(),
                r.getCustomerId(),
                customer.getName(),
                customer.getMobileNumber(),
                r.getGrandTotal(),
                items,
                agents,
                r.getGstin()
        ));

        return new BillingResponse("CREATED", r.getId());
    }

    public List<BillingQueueDto> pendingForAgent(String key) {
        User agent = userRepo.findBySseKey(key).orElseThrow();
        String gstin = mapRepo.findStoreForUser(agent.getId())
                .orElseThrow(() -> new RuntimeException("Agent not mapped to store"));
        return billingRepo.pendingForStore(gstin)
                .stream()
                .map(mapper::queue)
                .toList();
    }

    @Transactional
    public void approve(Long id) {
        BillingRequest r = billingRepo.lock(id);
        if (r.getStatus() != BillingRequest.Status.PENDING)
            throw new RuntimeException("Already processed");

        r.setStatus(BillingRequest.Status.APPROVED);
        billingRepo.save(r);

        // broadcast status change AFTER commit
        publisher.publishEvent(new BillingStatusEvent(r.getId(), r.getCustomerId(), "APPROVED", List.of()));
    }

    @Transactional
    public void reject(Long id) {
        BillingRequest r = billingRepo.lock(id);
        if (r.getStatus() != BillingRequest.Status.PENDING)
            throw new RuntimeException("Already processed");

        r.setStatus(BillingRequest.Status.REJECTED);
        billingRepo.save(r);

        publisher.publishEvent(new BillingStatusEvent(r.getId(), r.getCustomerId(), "REJECTED", List.of()));
    }

    @Transactional(readOnly = true)
    public BillingStatusDto billingStatus(String key, Long approvalId) {

        User customer = userRepo.findBySseKey(key)
                .orElseThrow(() -> new RuntimeException("Invalid key"));

        return billingRepo
                .findById(approvalId)
                .map(r -> new BillingStatusDto(
                        r.getStatus().name(),
                        r.getGrandTotal(),
                        r.getStampId(),
                        r.getExpiresAt()
                ))
                .orElse(new BillingStatusDto("NO_REQUEST", null, null, null));
    }

}