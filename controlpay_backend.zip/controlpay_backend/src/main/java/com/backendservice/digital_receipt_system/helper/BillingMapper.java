package com.backendservice.digital_receipt_system.helper;

import com.backendservice.digital_receipt_system.dto.BillingItemView;
import com.backendservice.digital_receipt_system.dto.BillingQueueDto;
import com.backendservice.digital_receipt_system.entities.BillingRequest;
import com.backendservice.digital_receipt_system.entities.User;
import com.backendservice.digital_receipt_system.repositories.BillingRequestItemRepository;
import com.backendservice.digital_receipt_system.repositories.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Maps BillingRequest entities to DTOs used for queue views.
 * Added logging for constructor and mapping method.
 */
@Component
public class BillingMapper {

    private static final Logger log = LoggerFactory.getLogger(BillingMapper.class);

    private final UserRepository userRepository;
    private final BillingRequestItemRepository billingRequestItemRepository;

    public BillingMapper(UserRepository userRepository, BillingRequestItemRepository billingRequestItemRepository) {
        this.userRepository = userRepository;
        this.billingRequestItemRepository = billingRequestItemRepository;
        log.debug("BillingMapper created with userRepository={} billingRequestItemRepository={}",
                userRepository != null ? userRepository.getClass().getSimpleName() : null,
                billingRequestItemRepository != null ? billingRequestItemRepository.getClass().getSimpleName() : null);
    }

    /**
     * Convert a BillingRequest entity to a BillingQueueDto for queue processing.
     *
     * @param r BillingRequest entity
     * @return BillingQueueDto with user details and item views
     */
    public BillingQueueDto queue(BillingRequest r) {
        log.debug("Entering BillingMapper.queue for requestId={}", r == null ? null : r.getId());
        try {
            User u = userRepository.findById(r.getCustomerId()).orElseThrow(() -> {
                var msg = "Customer user not found for id=" + r.getCustomerId();
                log.warn(msg);
                return new IllegalStateException(msg);
            });

            List<BillingItemView> items = billingRequestItemRepository.findViewsByRequest(r.getId());

            BillingQueueDto dto = new BillingQueueDto(
                    r.getId(),
                    u.getName(),
                    u.getMobileNumber(),
                    r.getGrandTotal(),
                    items
            );
            log.debug("Mapped BillingRequest {} to BillingQueueDto with {} items", r.getId(), items == null ? 0 : items.size());
            return dto;
        } catch (RuntimeException ex) {
            log.error("Error while mapping BillingRequest to BillingQueueDto for requestId={}", r == null ? null : r.getId(), ex);
            throw ex; // let global exception handler or caller handle the error
        }
    }
}