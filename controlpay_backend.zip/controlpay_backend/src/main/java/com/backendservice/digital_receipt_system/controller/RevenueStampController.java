//package com.backendservice.digital_receipt_system.controller;
//
//import com.backendservice.digital_receipt_system.dto.CreateStampRequest;
//import com.backendservice.digital_receipt_system.dto.CreateStampResponse;
//import com.backendservice.digital_receipt_system.dto.VerifyStampResponse;
//import com.backendservice.digital_receipt_system.entities.RevenueStamp;
//import com.backendservice.digital_receipt_system.services.RevenueStampService;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//@RestController
//@RequestMapping("/api/stamp")
//public class RevenueStampController {
//
//    private final RevenueStampService service;
//
//    public RevenueStampController(RevenueStampService service) {
//        this.service = service;
//    }
//
//    @PostMapping("/create")
//    public ResponseEntity<RevenueStamp> create(@RequestBody CreateStampRequest req) throws Exception {
//        var resp = service.createStamp(req);
//        return ResponseEntity.ok(resp);
//    }
//
//    @PostMapping("/verify")
//    public ResponseEntity<VerifyStampResponse> verify(@RequestParam String payloadJson, @RequestParam String signature) throws Exception {
//        var resp = service.verifyStamp(payloadJson, signature);
//        return ResponseEntity.ok(resp);
//    }
//}