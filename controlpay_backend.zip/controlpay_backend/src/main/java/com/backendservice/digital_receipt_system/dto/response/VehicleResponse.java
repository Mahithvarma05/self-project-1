package com.backendservice.digital_receipt_system.dto.response;

import com.backendservice.digital_receipt_system.entities.Vehicle;
import java.time.Instant;

public record VehicleResponse(
    Long id,
    String vehicleType,
    String numberPlate,
    String brand,
    String model,
    String color,
    Boolean isDefault,
    Instant createdAt
) {
    public static VehicleResponse from(Vehicle vehicle) {
        return new VehicleResponse(
            vehicle.getId(),
            vehicle.getVehicleType(),
            vehicle.getNumberPlate(),
            vehicle.getBrand(),
            vehicle.getModel(),
            vehicle.getColor(),
            vehicle.getIsDefault(),
            vehicle.getCreatedAt()
        );
    }
}