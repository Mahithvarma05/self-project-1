//package com.backendservice.digital_receipt_system.listener;
//
//import com.backendservice.digital_receipt_system.dto.CreateStampRequest;
//import com.backendservice.digital_receipt_system.events.BillingStatusEvent;
//import com.backendservice.digital_receipt_system.repositories.BillingRequestRepository;
//import com.backendservice.digital_receipt_system.services.RevenueStampService;
//import org.springframework.scheduling.annotation.Async;
//import org.springframework.stereotype.Component;
//import org.springframework.transaction.event.TransactionPhase;
//import org.springframework.transaction.event.TransactionalEventListener;
//
//import java.util.Map;
//
//@Component
//public class RevenueStampCreationListener {
//
//    private final RevenueStampService stampService;
//    private final BillingRequestRepository billingRepo;
//
//    public RevenueStampCreationListener(RevenueStampService stampService, BillingRequestRepository billingRepo) {
//        this.stampService = stampService;
//        this.billingRepo = billingRepo;
//    }
//
//    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
//    @Async // optional - run in separate thread pool
//    public void onBillingStatusChanged(BillingStatusEvent ev) {
//        if (!"APPROVED".equals(ev.status())) return;
//        Long billingId = ev.requestId();
//        try {
//            // Prepare metadata you want to include in stamp
//            Map<String,Object> metadata = Map.of(
//                "gstin", "..." /* or fetch from billing request if needed */,
//                "total", "...",
//                "issuedBy", "YourOrg"
//            );
//
//            CreateStampRequest req = new CreateStampRequest(billingId, metadata);
//            stampService.createStampAndAttach(billingId, req);
//        } catch (Exception ex) {
//            // log and alert: stamping failed — you may retry or queue
//        }
//    }
//}