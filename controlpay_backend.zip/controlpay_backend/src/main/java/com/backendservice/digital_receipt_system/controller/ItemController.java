package com.backendservice.digital_receipt_system.controller;

import com.backendservice.digital_receipt_system.dto.ItemDto;
import com.backendservice.digital_receipt_system.dto.ItemListDto;
import com.backendservice.digital_receipt_system.dto.request.BarcodeDetailsRequest;
import com.backendservice.digital_receipt_system.services.ItemService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping(path = "/v1/items",produces = MediaType.APPLICATION_JSON_VALUE)
@Validated

public class ItemController {

    private final ItemService service;

    public ItemController(ItemService service) {
        this.service = service;
    }

    // POST with JSON body: { "barcode": "12345" }
    @PostMapping("/barcode")
    public ResponseEntity<ItemDto> postByBarcode(@Valid @RequestBody BarcodeDetailsRequest request) {
        ItemDto dto = service.findByBarcode(request.getBarcode());
        return ResponseEntity.ok(dto);
    }

    @GetMapping("/all-products")
    public ResponseEntity<List<ItemListDto>> all() {
        return ResponseEntity.ok(service.allItems());
    }
}