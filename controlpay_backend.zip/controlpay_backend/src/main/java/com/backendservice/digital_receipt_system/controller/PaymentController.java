package com.backendservice.digital_receipt_system.controller;


import com.backendservice.digital_receipt_system.dto.response.VerifyPaymentResponse;
import com.backendservice.digital_receipt_system.dto.request.CreateOrderRequest;
import com.backendservice.digital_receipt_system.dto.request.VerifyPaymentRequest;
import com.backendservice.digital_receipt_system.dto.response.CreateOrderResponse;
import com.backendservice.digital_receipt_system.services.PaymentPersistenceService;
import com.backendservice.digital_receipt_system.services.PaymentService;
import com.razorpay.Order;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/v1/payments")
@Validated
public class PaymentController {

    private final PaymentService paymentService;
    private final PaymentPersistenceService persistenceService;

    public PaymentController(PaymentService paymentService, PaymentPersistenceService persistenceService) {
        this.paymentService = paymentService;
        this.persistenceService = persistenceService;
    }

    /**
     * Create Razorpay order (frontend uses order.id).
     * Persist the order record in DB after creating with Razorpay.
     */
    @PostMapping("/create-order")
    public ResponseEntity<CreateOrderResponse> createOrder(@Valid @RequestBody CreateOrderRequest request) throws Exception {
        Order order = paymentService.createOrder(request.getAmount(), request.getCurrency(), request.getReceipt());
        // Persist minimal order info
        persistenceService.saveOrderJson(order.toJson().toString());
        CreateOrderResponse resp = new CreateOrderResponse(order.toJson());
        return ResponseEntity.ok(resp);
    }

    /**
     * Verify payment signature (client can call after successful payment to verify)
     */
    @PostMapping("/verify")
    public ResponseEntity<VerifyPaymentResponse> verifyPayment(
            @Valid @RequestBody VerifyPaymentRequest req
    ) {
        String payload = req.getRazorpayOrderId() + "|" + req.getRazorpayPaymentId();

        boolean ok = paymentService.verifyClientSignature(payload, req.getRazorpaySignature());

        if (ok) {
            return ResponseEntity.ok(
                    VerifyPaymentResponse.success()
            );
        } else {
            return ResponseEntity.badRequest().body(
                    VerifyPaymentResponse.failed()
            );
        }
    }

}