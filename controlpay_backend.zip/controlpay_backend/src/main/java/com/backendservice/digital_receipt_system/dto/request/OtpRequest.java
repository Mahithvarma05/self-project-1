package com.backendservice.digital_receipt_system.dto.request;

import jakarta.validation.constraints.NotBlank;

public record OtpRequest(
    @NotBlank String mobile
) {}