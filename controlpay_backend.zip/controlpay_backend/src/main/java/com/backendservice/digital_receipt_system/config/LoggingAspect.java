package com.backendservice.digital_receipt_system.config;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Arrays;

/**
 * Logging aspect which logs method entry, exit (with return value) and exceptions for public methods
 * within the application's base package.
 *
 * This ensures logging coverage for:
 * - Explicitly written methods
 * - Lombok-generated methods (getters/setters/toString/etc.)
 * - Records (their methods), and any other methods under the package
 *
 * IMPORTANT:
 * - Add dependency 'spring-boot-starter-aop' to enable Spring AOP.
 * - Tune the pointcut expression as needed to include/exclude packages or classes.
 */
@Aspect
@Component
public class LoggingAspect {

    private static final Logger log = LoggerFactory.getLogger(LoggingAspect.class);

    /**
     * Around advice for all public methods in com.backendservice.digital_receipt_system..*
     * Adjust the package path if you want to narrow or expand the scope.
     */
    @Around("execution(public * com.backendservice.digital_receipt_system..*(..))")
    public Object logAround(ProceedingJoinPoint pjp) throws Throwable {
        MethodSignature signature = (MethodSignature) pjp.getSignature();
        String className = signature.getDeclaringType().getSimpleName();
        String methodName = signature.getName();
        Object[] args = pjp.getArgs();

        long start = System.currentTimeMillis();
        if (log.isDebugEnabled()) {
            log.debug("Enter {}.{}() with arguments={}", className, methodName, Arrays.toString(args));
        } else {
            log.info("Enter {}.{}()", className, methodName);
        }

        try {
            Object result = pjp.proceed();
            long elapsed = System.currentTimeMillis() - start;
            if (log.isDebugEnabled()) {
                log.debug("Exit {}.{}() with result={} ({} ms)", className, methodName, result, elapsed);
            } else {
                log.info("Exit {}.{}() ({} ms)", className, methodName, elapsed);
            }
            return result;
        } catch (Throwable ex) {
            long elapsed = System.currentTimeMillis() - start;
            log.error("Exception in {}.{}() after {} ms: {}", className, methodName, elapsed, ex.getMessage(), ex);
            throw ex;
        }
    }
}