package com.backendservice.digital_receipt_system.services;

import com.backendservice.digital_receipt_system.entities.User;
import com.backendservice.digital_receipt_system.exceptions.EkycVerificationException;
import com.backendservice.digital_receipt_system.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.SecureRandom;
import java.util.HexFormat;
import java.util.Optional;

/**
 * User registration service with optional eKYC verification (Aadhaar/PAN).
 */
@Service
public class UserRegistrationService {

    private final UserRepository userRepo;
    private final EkycService ekycService;
    private final SecureRandom secureRandom = new SecureRandom();

    // default role for newly registered users; adapt if you want other defaults
    private static final String DEFAULT_ROLE = "CUSTOMER";

    // Flag to require at least one eKYC (aadhaar or pan) on registration
    private final boolean requireEkyc;

    public UserRegistrationService(UserRepository userRepo, EkycService ekycService,
                                   @Value("${ekyc.require-verification:false}") boolean requireEkyc) {
        this.userRepo = userRepo;
        this.ekycService = ekycService;
        this.requireEkyc = requireEkyc;
    }

    @Transactional
    public User register(String name, String mobile, String rawPassword, String aadhaar, String pan) {

        String normalizedMobile = normalizeMobile(mobile);

        if (userRepo.existsByMobileNumber(normalizedMobile)) {
            throw new RuntimeException("Mobile number already registered");
        }

        // If eKYC required: ensure provider enabled and either aadhaar or pan is provided and verified
        if (requireEkyc) {
            if (!ekycService.isEnabled()) {
                throw new RuntimeException("eKYC configured as required but service is disabled");
            }
            boolean verified = false;
            String cause = null;
            if (aadhaar != null && !aadhaar.isBlank()) {
                try {
                    verified = ekycService.verifyAadhaar(aadhaar, name);
                    if (!verified) cause = "Aadhaar verification failed";
                } catch (EkycVerificationException ex) {
                    throw new RuntimeException("Aadhaar verification failed: " + ex.getMessage(), ex);
                }
            }
            if (!verified && pan != null && !pan.isBlank()) {
                try {
                    verified = ekycService.verifyPan(pan, name);
                    if (!verified) cause = "PAN verification failed";
                } catch (EkycVerificationException ex) {
                    throw new RuntimeException("PAN verification failed: " + ex.getMessage(), ex);
                }
            }
            if (!verified) {
                throw new RuntimeException("eKYC verification required. " + (cause == null ? "No valid document provided" : cause));
            }
        } else {
            // eKYC optional — if provider enabled and fields present, try verification but do not fail registration on verification failure
            try {
                if (ekycService.isEnabled()) {
                    if (aadhaar != null && !aadhaar.isBlank()) {
                        boolean ok = ekycService.verifyAadhaar(aadhaar, name);
                        if (!ok) {
                            // log but continue registration
                        }
                    }
                    if (pan != null && !pan.isBlank()) {
                        boolean ok = ekycService.verifyPan(pan, name);
                        if (!ok) {
                            // log but continue
                        }
                    }
                }
            } catch (Exception ex) {
                // Provider call failure — do not block registration when eKYC not required
            }
        }

        // hash password using BCrypt
        String hashed = BCrypt.hashpw(rawPassword, BCrypt.gensalt());

        // generate unique SSE key
        String sseKey = generateUniqueSseKey();

        User u = new User();
        u.setName(name);
        u.setMobileNumber(normalizedMobile);
        u.setPassword(hashed);
        u.setRole(DEFAULT_ROLE);
        u.setActive(true);
        u.setPushToken(null);
        u.setSseKey(sseKey);

        return userRepo.save(u);
    }

    private String normalizeMobile(String m) {
        if (m == null) return null;
        String s = m.trim();
        if (s.startsWith("+")) {
            return "+" + s.substring(1).replaceAll("\\D", "");
        }

        return s.replaceAll("\\D", "");
    }

    private String generateUniqueSseKey() {
        for (int attempt = 0; attempt < 8; attempt++) {
            byte[] b = new byte[32];
            secureRandom.nextBytes(b);
            String candidate = HexFormat.of().formatHex(b);
            Optional<User> existing = userRepo.findBySseKey(candidate);
            if (existing.isEmpty()) return candidate;
        }
        byte[] b = new byte[32];
        secureRandom.nextBytes(b);
        return HexFormat.of().formatHex(b);
    }
}