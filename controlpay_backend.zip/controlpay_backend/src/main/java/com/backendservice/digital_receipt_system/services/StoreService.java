package com.backendservice.digital_receipt_system.services;

import com.backendservice.digital_receipt_system.dto.StoreDto;
import com.backendservice.digital_receipt_system.entities.Store;
import com.backendservice.digital_receipt_system.exceptions.StoreNotFoundException;
import com.backendservice.digital_receipt_system.repositories.StoreRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class StoreService {
    private final StoreRepository repository;

    public StoreService(StoreRepository repository) {
        this.repository = repository;
    }

    @Transactional(readOnly = true)
    public StoreDto findByGstin(String gstin) {
        return repository.findDtoByGstin(gstin)
                .orElseThrow(() -> new StoreNotFoundException(gstin));
    }
}