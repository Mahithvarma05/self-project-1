package com.backendservice.digital_receipt_system.repositories;

import com.backendservice.digital_receipt_system.entities.Vehicle;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import java.util.List;
import java.util.Optional;

public interface VehicleRepository extends JpaRepository<Vehicle, Long> {
    List<Vehicle> findByUserIdOrderByIsDefaultDescCreatedAtDesc(Long userId);
    Optional<Vehicle> findByUserIdAndNumberPlate(Long userId, String numberPlate);
    Optional<Vehicle> findByUserIdAndIsDefaultTrue(Long userId);
    
    @Modifying
    @Query("UPDATE Vehicle v SET v.isDefault = false WHERE v.userId = :userId")
    void clearDefaultForUser(Long userId);
}