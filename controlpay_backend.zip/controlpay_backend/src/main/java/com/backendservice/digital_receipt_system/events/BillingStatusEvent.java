package com.backendservice.digital_receipt_system.events;

import java.util.List;

public record BillingStatusEvent(
        Long requestId,
        Long customerId,
        String status,
        List<Long> agentIds
) {}