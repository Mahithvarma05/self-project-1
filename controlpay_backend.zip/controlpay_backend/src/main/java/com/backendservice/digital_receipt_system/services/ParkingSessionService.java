package com.backendservice.digital_receipt_system.services;

import com.backendservice.digital_receipt_system.dto.request.ExitParkingRequest;
import com.backendservice.digital_receipt_system.dto.request.StartParkingRequest;
import com.backendservice.digital_receipt_system.dto.response.ParkingFareResponse;
import com.backendservice.digital_receipt_system.dto.response.ParkingSessionResponse;
import com.backendservice.digital_receipt_system.entities.ParkingArea;
import com.backendservice.digital_receipt_system.entities.ParkingSession;
import com.backendservice.digital_receipt_system.entities.Vehicle;
import com.backendservice.digital_receipt_system.repositories.ParkingAreaRepository;
import com.backendservice.digital_receipt_system.repositories.ParkingSessionRepository;
import com.backendservice.digital_receipt_system.repositories.VehicleRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.Instant;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class ParkingSessionService {
    
    private final ParkingSessionRepository sessionRepo;
    private final ParkingAreaRepository parkingAreaRepo;
    private final VehicleRepository vehicleRepo;
    
    @Transactional
    public ParkingSessionResponse startSession(Long userId, StartParkingRequest request) {
        
        // Check if user already has an active session
        Optional<ParkingSession> existingSession = sessionRepo.findActiveSessionByUserId(userId);
        if (existingSession.isPresent()) {
            throw new RuntimeException("You already have an active parking session");
        }
        
        // Validate parking area
        ParkingArea parkingArea = parkingAreaRepo.findByAreaCode(request.getAreaCode())
            .orElseThrow(() -> new RuntimeException("Invalid parking area code"));
        
        if (!parkingArea.getIsActive()) {
            throw new RuntimeException("This parking area is currently inactive");
        }
        
        // Check capacity
        Long activeCount = sessionRepo.countActiveSessionsByParkingArea(parkingArea.getId());
        if (parkingArea.getTotalCapacity() != null && 
            activeCount >= parkingArea.getTotalCapacity()) {
            throw new RuntimeException("Parking area is full");
        }
        
        // Get vehicle details
        String vehicleType;
        String numberPlate;
        
        if (request.getVehicleId() != null) {
            // Use pre-saved vehicle
            Vehicle vehicle = vehicleRepo.findById(request.getVehicleId())
                .orElseThrow(() -> new RuntimeException("Vehicle not found"));
            
            if (!vehicle.getUserId().equals(userId)) {
                throw new RuntimeException("Unauthorized vehicle access");
            }
            
            vehicleType = vehicle.getVehicleType();
            numberPlate = vehicle.getNumberPlate();
        } else {
            // Use new vehicle details
            if (request.getVehicleType() == null || request.getNumberPlate() == null) {
                throw new RuntimeException("Vehicle details are required");
            }
            vehicleType = request.getVehicleType();
            numberPlate = request.getNumberPlate().toUpperCase();
        }
        
        // Create session
        ParkingSession session = new ParkingSession();
        session.setUserId(userId);
        session.setVehicleId(request.getVehicleId());
        session.setParkingAreaId(parkingArea.getId());
        session.setVehicleType(vehicleType);
        session.setNumberPlate(numberPlate);
        session.setStartTime(Instant.now());
        session.setHourlyRate(parkingArea.getHourlyRate());
        session.setStatus(ParkingSession.Status.ACTIVE);
        
        ParkingSession saved = sessionRepo.save(session);
        
        log.info("Parking session started: sessionId={}, userId={}, areaId={}", 
                 saved.getId(), userId, parkingArea.getId());
        
        return ParkingSessionResponse.from(saved, parkingArea.getName());
    }
    
    @Transactional
    public ParkingFareResponse initiateExit(Long userId, ExitParkingRequest request) {
        
        // Get active session
        ParkingSession session = sessionRepo.findActiveSessionByUserId(userId)
            .orElseThrow(() -> new RuntimeException("No active parking session found"));
        
        // Validate parking area
        ParkingArea parkingArea = parkingAreaRepo.findByAreaCode(request.getAreaCode())
            .orElseThrow(() -> new RuntimeException("Invalid parking area code"));
        
        if (!session.getParkingAreaId().equals(parkingArea.getId())) {
            throw new RuntimeException("You must exit from the same parking area where you entered");
        }
        
        // Calculate duration and fare
        Instant exitTime = Instant.now();
        session.setExitTime(exitTime);
        
        Duration duration = Duration.between(session.getStartTime(), exitTime);
        long durationMinutes = duration.toMinutes();
        session.setDurationMinutes(durationMinutes);
        
        // Calculate fare (round up to nearest hour)
        long durationHours = (long) Math.ceil(durationMinutes / 60.0);
        BigDecimal totalAmount = BigDecimal.valueOf(durationHours)
            .multiply(BigDecimal.valueOf(session.getHourlyRate()))
            .setScale(2, RoundingMode.HALF_UP);
        
        session.setTotalAmount(totalAmount);
        session.setStatus(ParkingSession.Status.PENDING_PAYMENT);
        
        ParkingSession updated = sessionRepo.save(session);
        
        log.info("Exit initiated: sessionId={}, duration={}min, amount={}", 
                 updated.getId(), durationMinutes, totalAmount);
        
        return new ParkingFareResponse(
            updated.getId(),
            updated.getSessionCode(),
            updated.getStartTime(),
            updated.getExitTime(),
            durationMinutes,
            durationHours,
            updated.getHourlyRate(),
            totalAmount,
            updated.getStatus().name()
        );
    }
    
    @Transactional(readOnly = true)
    public Optional<ParkingSessionResponse> getActiveSession(Long userId) {
        return sessionRepo.findActiveSessionByUserId(userId)
            .map(session -> {
                ParkingArea area = parkingAreaRepo.findById(session.getParkingAreaId())
                    .orElse(null);
                return ParkingSessionResponse.from(session, 
                    area != null ? area.getName() : "Unknown");
            });
    }
    
    @Transactional(readOnly = true)
    public Page<ParkingSessionResponse> getUserSessions(Long userId, Pageable pageable) {
        return sessionRepo.findByUserId(userId, pageable)
            .map(session -> {
                ParkingArea area = parkingAreaRepo.findById(session.getParkingAreaId())
                    .orElse(null);
                return ParkingSessionResponse.from(session, 
                    area != null ? area.getName() : "Unknown");
            });
    }
    
    @Transactional
    public void completePayment(Long sessionId, String razorpayOrderId) {
        ParkingSession session = sessionRepo.findById(sessionId)
            .orElseThrow(() -> new RuntimeException("Session not found"));
        
        if (session.getStatus() != ParkingSession.Status.PENDING_PAYMENT) {
            throw new RuntimeException("Invalid session status for payment completion");
        }
        
        session.setRazorpayOrderId(razorpayOrderId);
        session.setStatus(ParkingSession.Status.PAID);
        session.setEndTime(Instant.now());
        
        sessionRepo.save(session);
        
        log.info("Parking payment completed: sessionId={}, orderId={}", 
                 sessionId, razorpayOrderId);
    }

    @Transactional(readOnly = true)
    public ParkingFareResponse getSessionFare(Long sessionId, Long userId) {
        ParkingSession session = sessionRepo.findById(sessionId)
                .orElseThrow(() -> new RuntimeException("Session not found"));

        if (!session.getUserId().equals(userId)) {
            throw new RuntimeException("Unauthorized access");
        }

        if (session.getStatus() != ParkingSession.Status.PENDING_PAYMENT) {
            throw new RuntimeException("Session is not in PENDING_PAYMENT status");
        }

        long durationHours = (long) Math.ceil(session.getDurationMinutes() / 60.0);

        return new ParkingFareResponse(
                session.getId(),
                session.getSessionCode(),
                session.getStartTime(),
                session.getExitTime(),
                session.getDurationMinutes(),
                durationHours,
                session.getHourlyRate(),
                session.getTotalAmount(),
                session.getStatus().name()
        );
    }
}