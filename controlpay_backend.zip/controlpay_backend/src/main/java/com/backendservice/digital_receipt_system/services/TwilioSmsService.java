package com.backendservice.digital_receipt_system.services;

import com.backendservice.digital_receipt_system.entities.PaymentTransaction;
import com.backendservice.digital_receipt_system.repositories.PaymentTransactionRepository;
//import com.twilio.security.RequestValidator;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class TwilioSmsService {

    private final PaymentTransactionRepository txRepo;
    // Optional: Twilio auth token for inbound request validation
    private final String twilioAuthToken;

    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public TwilioSmsService(PaymentTransactionRepository txRepo,
                            @Value("${twilio.auth-token:}") String twilioAuthToken) {
        this.txRepo = txRepo;
        this.twilioAuthToken = twilioAuthToken;
    }

    /**
     * Process incoming SMS.
     * - If body equals "statement" (case-insensitive), fetch last five transactions for the sender number.
     * - Otherwise reply with a short help text.
     */
    public String processIncomingSms(String from, String body) {
        if (body == null) body = "";
        String cmd = body.trim().toLowerCase(Locale.ROOT);

        if ("statement".equals(cmd) || cmd.startsWith("statement ")) {
            return handleStatementRequest(from);
        } else {
            return helpText();
        }
    }

    private String helpText() {
        return "Reply with \"statement\" to get your last 5 transactions.";
    }
    

    private String handleStatementRequest(String from) {
        if (from == null || from.isBlank()) {
            return "Could not determine your phone number. Please try again.";
        }

        // Normalize common variants of phone number used in DB vs Twilio:
        // Twilio sends E.164 like +911234567890. Try several variants.
        List<String> candidates = phoneCandidates(from);

        List<PaymentTransaction> txs = Collections.emptyList();
        for (String c : candidates) {
            txs = txRepo.findTop5ByContactOrderByCreatedAtDesc(c);
            if (!txs.isEmpty()) break;
        }

        if (txs.isEmpty()) {
            return "No recent transactions found for your number.";
        }

        // Format message
        StringBuilder sb = new StringBuilder();
        sb.append("Last ").append(Math.min(5, txs.size())).append(" transactions:\n");
        int i = 1;
        for (PaymentTransaction t : txs) {
            String date = t.getCreatedAt() == null ? "" : DATE_FMT.format(t.getCreatedAt().atZone(java.time.ZoneId.systemDefault()).toLocalDate());
            BigDecimal amount = BigDecimal.valueOf(Optional.ofNullable(t.getAmount()).orElse(0L))
                    .divide(BigDecimal.valueOf(100)); // amount stored in paise
            String amt = "₹" + amount.setScale(2, BigDecimal.ROUND_HALF_UP).toPlainString();
            String status = Optional.ofNullable(t.getStatus()).orElse("");
            String pid = Optional.ofNullable(t.getRazorpayPaymentId()).orElse("");
            String pidShort = pid.length() > 8 ? pid.substring(pid.length() - 8) : pid;
            sb.append(i++).append(". ").append(date).append(" ").append(amt).append(" ").append(status);
            if (!pidShort.isBlank()) sb.append(" id:").append(pidShort);
            if (i <= 6) sb.append("\n");
        }
        return sb.toString().trim();
    }

    /**
     * Produce several phone variants to increase the chance of matching how contact is stored in DB.
     * e.g. +911234..., 911234..., 1234...
     */
    private List<String> phoneCandidates(String from) {
        String s = from.trim();
        List<String> out = new ArrayList<>();
        out.add(s);
        // remove leading +
        if (s.startsWith("+")) {
            out.add(s.substring(1));
        }
        // remove country code if present (naive): try drop first 2-4 digits
        String justDigits = s.replaceAll("\\D", "");
        out.add(justDigits);
        if (justDigits.length() > 10) {
            out.add(justDigits.substring(justDigits.length() - 10)); // local 10-digit
        }
        // also try with leading 0
        if (!justDigits.startsWith("0")) {
            out.add("0" + justDigits);
        }
        // dedupe but keep order
        return out.stream().filter(x -> x != null && !x.isBlank()).distinct().collect(Collectors.toList());
    }

    /**
     * Optional: verify Twilio request signature. Requires Twilio helper dependency.
     * Example usage (not called by default):
     *
     * RequestValidator validator = new RequestValidator(twilioAuthToken);
     * boolean valid = validator.validate(url, paramsMap, signatureHeader);
     *
     * If you want request validation enable it and inject the signature header and the webhook URL.
     */
//    public boolean verifyRequest(String url, Map<String, String> params, String twilioSignature) {
//        if (twilioAuthToken == null || twilioAuthToken.isBlank()) {
//            return false; // not configured
//        }
//        RequestValidator validator = new RequestValidator(twilioAuthToken);
//        return validator.validate(url, params, twilioSignature);
//    }
}