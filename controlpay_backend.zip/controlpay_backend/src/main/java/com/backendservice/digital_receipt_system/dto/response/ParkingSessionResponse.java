package com.backendservice.digital_receipt_system.dto.response;

import com.backendservice.digital_receipt_system.entities.ParkingSession;
import java.math.BigDecimal;
import java.time.Instant;

public record ParkingSessionResponse(
    Long id,
    String sessionCode,
    Long parkingAreaId,
    String parkingAreaName,
    String vehicleType,
    String numberPlate,
    Instant startTime,
    Instant exitTime,
    Instant endTime,
    Long durationMinutes,
    Integer hourlyRate,
    BigDecimal totalAmount,
    String status,
    String razorpayOrderId
) {
    public static ParkingSessionResponse from(ParkingSession session, String areaName) {
        return new ParkingSessionResponse(
            session.getId(),
            session.getSessionCode(),
            session.getParkingAreaId(),
            areaName,
            session.getVehicleType(),
            session.getNumberPlate(),
            session.getStartTime(),
            session.getExitTime(),
            session.getEndTime(),
            session.getDurationMinutes(),
            session.getHourlyRate(),
            session.getTotalAmount(),
            session.getStatus().name(),
            session.getRazorpayOrderId()
        );
    }
}