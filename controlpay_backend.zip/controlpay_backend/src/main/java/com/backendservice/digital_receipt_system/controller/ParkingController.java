// src/main/java/com/backendservice/digital_receipt_system/controller/ParkingController.java
package com.backendservice.digital_receipt_system.controller;

import com.backendservice.digital_receipt_system.dto.ApiSuccess;
import com.backendservice.digital_receipt_system.dto.request.CreateOrderRequest;
import com.backendservice.digital_receipt_system.dto.request.ExitParkingRequest;
import com.backendservice.digital_receipt_system.dto.request.StartParkingRequest;
import com.backendservice.digital_receipt_system.dto.response.CreateOrderResponse;
import com.backendservice.digital_receipt_system.dto.response.ParkingFareResponse;
import com.backendservice.digital_receipt_system.dto.response.ParkingSessionResponse;
import com.backendservice.digital_receipt_system.entities.User;
import com.backendservice.digital_receipt_system.repositories.UserRepository;
import com.backendservice.digital_receipt_system.services.ParkingSessionService;
import com.backendservice.digital_receipt_system.services.PaymentService;
import com.razorpay.Order;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/parking")
@RequiredArgsConstructor
public class ParkingController {
    
    private final ParkingSessionService parkingService;
    private final PaymentService paymentService;
    private final UserRepository userRepo;
    
    @PostMapping("/start")
    public ResponseEntity<ParkingSessionResponse> startParking(
            @RequestHeader("X-ACCESS-KEY") String key,
            @Valid @RequestBody StartParkingRequest request) {
        
        User user = userRepo.findBySseKey(key)
            .orElseThrow(() -> new RuntimeException("Invalid access key"));
        
        ParkingSessionResponse response = parkingService.startSession(user.getId(), request);
        return ResponseEntity.ok(response);
    }
    
    @PostMapping("/exit")
    public ResponseEntity<ParkingFareResponse> initiateExit(
            @RequestHeader("X-ACCESS-KEY") String key,
            @Valid @RequestBody ExitParkingRequest request) {
        
        User user = userRepo.findBySseKey(key)
            .orElseThrow(() -> new RuntimeException("Invalid access key"));
        
        ParkingFareResponse response = parkingService.initiateExit(user.getId(), request);
        return ResponseEntity.ok(response);
    }
    
    @GetMapping("/active-session")
    public ResponseEntity<?> getActiveSession(
            @RequestHeader("X-ACCESS-KEY") String key) {
        
        User user = userRepo.findBySseKey(key)
            .orElseThrow(() -> new RuntimeException("Invalid access key"));
        
        Optional<ParkingSessionResponse> session = parkingService.getActiveSession(user.getId());
        
        if (session.isEmpty()) {
            return ResponseEntity.ok().body(new ApiSuccess("No active session"));
        }
        
        return ResponseEntity.ok(session.get());
    }
    
    @GetMapping("/history")
    public ResponseEntity<Page<ParkingSessionResponse>> getHistory(
            @RequestHeader("X-ACCESS-KEY") String key,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        
        User user = userRepo.findBySseKey(key)
            .orElseThrow(() -> new RuntimeException("Invalid access key"));
        
        Pageable pageable = PageRequest.of(page, size, 
            Sort.by(Sort.Direction.DESC, "createdAt"));
        
        Page<ParkingSessionResponse> history = parkingService.getUserSessions(user.getId(), pageable);
        return ResponseEntity.ok(history);
    }
    
    @PostMapping("/session/{sessionId}/create-payment")
    public ResponseEntity<CreateOrderResponse> createPaymentOrder(
            @RequestHeader("X-ACCESS-KEY") String key,
            @PathVariable Long sessionId) throws Exception {
        
        User user = userRepo.findBySseKey(key)
            .orElseThrow(() -> new RuntimeException("Invalid access key"));
        
        // Get session and create payment order
        // Note: You'll need to add a method to get session by ID
        ParkingFareResponse fare = parkingService.getSessionFare(sessionId, user.getId());
        
        Order order = paymentService.createOrder(
            fare.totalAmount(), 
            "INR", 
            "parking-" + sessionId
        );
        
        CreateOrderResponse response = new CreateOrderResponse(order.toJson());
        return ResponseEntity.ok(response);
    }
}