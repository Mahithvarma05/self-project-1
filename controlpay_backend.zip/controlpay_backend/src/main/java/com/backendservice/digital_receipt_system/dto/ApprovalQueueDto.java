package com.backendservice.digital_receipt_system.dto;

import java.time.Instant;

public record ApprovalQueueDto(
        Long requestId,
        String customerName,
        String mobileNumber,
        Instant requestedAt,
        Long customerId
) {}
