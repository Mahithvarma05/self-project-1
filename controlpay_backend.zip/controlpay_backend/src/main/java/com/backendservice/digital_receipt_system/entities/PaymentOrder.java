package com.backendservice.digital_receipt_system.entities;

import jakarta.persistence.*;
import lombok.Data;

import java.time.Instant;

@Entity
@Table(name = "payment_orders", indexes = {
        @Index(name = "idx_payment_orders_razorpay_order_id", columnList = "razorpay_order_id", unique = true)
})
@Data
public class PaymentOrder {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "razorpay_order_id", nullable = false, unique = true, length = 128)
    private String razorpayOrderId;

    @Column(nullable = false)
    private Long amount; // in paise

    @Column(length = 8)
    private String currency;

    @Column(length = 128)
    private String receipt;

    @Column(length = 64)
    private String status;

    @Column(name = "amount_paid")
    private Long amountPaid;

    @Column(name = "amount_due")
    private Long amountDue;

    @Version
    private Long version;

    @Column(name = "created_at", nullable = false)
    private Instant createdAt = Instant.now();

    @Column(name = "updated_at")
    private Instant updatedAt = Instant.now();

    @Column(name = "payment_mode", length = 20)
    private String paymentMode;

    public PaymentOrder() {}

    @PrePersist
    public void prePersist() {
        Instant now = Instant.now();
        if (this.createdAt == null) this.createdAt = now;
        if (this.updatedAt == null) this.updatedAt = now;
    }

    @PreUpdate
    public void preUpdate() {
        this.updatedAt = Instant.now();
    }

}