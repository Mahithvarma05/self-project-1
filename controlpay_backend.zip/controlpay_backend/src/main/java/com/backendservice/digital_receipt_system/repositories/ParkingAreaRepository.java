package com.backendservice.digital_receipt_system.repositories;

import com.backendservice.digital_receipt_system.entities.ParkingArea;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface ParkingAreaRepository extends JpaRepository<ParkingArea, Long> {
    Optional<ParkingArea> findByAreaCode(String areaCode);
    List<ParkingArea> findByMerchantGstinAndIsActiveTrue(String merchantGstin);
    boolean existsByAreaCode(String areaCode);
}