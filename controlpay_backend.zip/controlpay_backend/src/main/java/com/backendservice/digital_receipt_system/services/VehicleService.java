package com.backendservice.digital_receipt_system.services;

import com.backendservice.digital_receipt_system.dto.request.SaveVehicleRequest;
import com.backendservice.digital_receipt_system.dto.response.VehicleResponse;
import com.backendservice.digital_receipt_system.entities.User;
import com.backendservice.digital_receipt_system.entities.Vehicle;
import com.backendservice.digital_receipt_system.repositories.VehicleRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class VehicleService {
    
    private final VehicleRepository vehicleRepo;
    
    @Transactional
    public VehicleResponse saveVehicle(Long userId, SaveVehicleRequest request) {
        
        // Check if vehicle already exists
        vehicleRepo.findByUserIdAndNumberPlate(userId, request.getNumberPlate())
            .ifPresent(v -> {
                throw new RuntimeException("Vehicle with this number plate already exists");
            });
        
        // If setting as default, clear other defaults
        if (Boolean.TRUE.equals(request.getIsDefault())) {
            vehicleRepo.clearDefaultForUser(userId);
        }
        
        Vehicle vehicle = new Vehicle();
        vehicle.setUserId(userId);
        vehicle.setVehicleType(request.getVehicleType());
        vehicle.setNumberPlate(request.getNumberPlate().toUpperCase());
        vehicle.setBrand(request.getBrand());
        vehicle.setModel(request.getModel());
        vehicle.setColor(request.getColor());
        vehicle.setIsDefault(request.getIsDefault());
        
        Vehicle saved = vehicleRepo.save(vehicle);
        return VehicleResponse.from(saved);
    }
    
    @Transactional(readOnly = true)
    public List<VehicleResponse> getUserVehicles(Long userId) {
        return vehicleRepo.findByUserIdOrderByIsDefaultDescCreatedAtDesc(userId)
            .stream()
            .map(VehicleResponse::from)
            .toList();
    }
    
    @Transactional
    public void deleteVehicle(Long userId, Long vehicleId) {
        Vehicle vehicle = vehicleRepo.findById(vehicleId)
            .orElseThrow(() -> new RuntimeException("Vehicle not found"));
        
        if (!vehicle.getUserId().equals(userId)) {
            throw new RuntimeException("Unauthorized access");
        }
        
        vehicleRepo.delete(vehicle);
    }
    
    @Transactional
    public VehicleResponse setDefaultVehicle(Long userId, Long vehicleId) {
        Vehicle vehicle = vehicleRepo.findById(vehicleId)
            .orElseThrow(() -> new RuntimeException("Vehicle not found"));
        
        if (!vehicle.getUserId().equals(userId)) {
            throw new RuntimeException("Unauthorized access");
        }
        
        vehicleRepo.clearDefaultForUser(userId);
        vehicle.setIsDefault(true);
        Vehicle updated = vehicleRepo.save(vehicle);
        
        return VehicleResponse.from(updated);
    }
}