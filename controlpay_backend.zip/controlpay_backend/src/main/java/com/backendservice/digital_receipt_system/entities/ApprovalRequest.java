package com.backendservice.digital_receipt_system.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;
import java.time.temporal.ChronoUnit;

@Entity
@Table(
    name = "approval_requests"
)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ApprovalRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "customer_id", nullable = false)
    private Long customerId;

    @Column(name = "store_gstin", nullable = false, length = 15)
    private String storeGstin;

    @Column(nullable = false, length = 20)
    private String status; // PENDING / APPROVED / REJECTED / EXPIRED

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "expires_at", nullable = false)
    private Instant expiresAt;

    @Column(name = "updated_at")
    private Instant updatedAt;

    public ApprovalRequest(Long customerId, String storeGstin) {
        this.customerId = customerId;
        this.storeGstin = storeGstin;
    }

    @PrePersist
    public void prePersist() {
        this.createdAt = Instant.now();
        this.expiresAt = createdAt.plus(30, ChronoUnit.MINUTES);
        this.status = "PENDING";
    }


    @PreUpdate
    public void preUpdate() {
        this.updatedAt = Instant.now();
    }
}
