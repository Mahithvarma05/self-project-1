package com.backendservice.digital_receipt_system.repositories;

import com.backendservice.digital_receipt_system.entities.OtpCode;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface OtpCodeRepository extends JpaRepository<OtpCode, Long> {
    Optional<OtpCode> findTopByMobileNumberOrderByCreatedAtDesc(String mobileNumber);
}