package com.backendservice.digital_receipt_system.entities;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "payment_transactions", indexes = {
        @Index(name = "idx_payment_transactions_razorpay_payment_id", columnList = "razorpay_payment_id", unique = true)
})
public class PaymentTransaction {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "razorpay_payment_id", nullable = false, unique = true, length = 128)
    private String razorpayPaymentId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "payment_order_id")
    private PaymentOrder paymentOrder;

    @Column(nullable = false)
    private Long amount; // in paise

    @Column(length = 8)
    private String currency;

    @Column(length = 64)
    private String status;

    @Column(length = 64)
    private String method;

    @Column(length = 128)
    private String email;

    @Column(length = 32)
    private String contact;

    @Column(nullable = false)
    private Boolean captured = false;

    @Column(name = "created_at", nullable = false)
    private Instant createdAt = Instant.now();

    public PaymentTransaction() {}

    @PrePersist
    public void prePersist() {
        if (this.createdAt == null) {
            this.createdAt = Instant.now();
        }
    }

    // Getters and setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getRazorpayPaymentId() { return razorpayPaymentId; }
    public void setRazorpayPaymentId(String razorpayPaymentId) { this.razorpayPaymentId = razorpayPaymentId; }

    public PaymentOrder getPaymentOrder() { return paymentOrder; }
    public void setPaymentOrder(PaymentOrder paymentOrder) { this.paymentOrder = paymentOrder; }

    public Long getAmount() { return amount; }
    public void setAmount(Long amount) { this.amount = amount; }

    public String getCurrency() { return currency; }
    public void setCurrency(String currency) { this.currency = currency; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getMethod() { return method; }
    public void setMethod(String method) { this.method = method; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getContact() { return contact; }
    public void setContact(String contact) { this.contact = contact; }

    public Boolean getCaptured() { return captured; }
    public void setCaptured(Boolean captured) { this.captured = captured; }

    public Instant getCreatedAt() { return createdAt; }
    public void setCreatedAt(Instant createdAt) { this.createdAt = createdAt; }
}