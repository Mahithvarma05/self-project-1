package com.backendservice.digital_receipt_system.dto;

import java.math.BigDecimal;

public record ItemLiteDto(Long id, String name, BigDecimal price, BigDecimal gstPercentage) {}