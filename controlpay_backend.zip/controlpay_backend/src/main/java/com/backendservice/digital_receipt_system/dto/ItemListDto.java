package com.backendservice.digital_receipt_system.dto;

import java.math.BigDecimal;

public record ItemListDto(
        Long id,
        String barcode,
        String name,
        BigDecimal price,
        BigDecimal gstPercentage
) {}
