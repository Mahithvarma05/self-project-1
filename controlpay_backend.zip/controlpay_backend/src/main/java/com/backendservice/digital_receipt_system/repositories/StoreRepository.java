package com.backendservice.digital_receipt_system.repositories;

import com.backendservice.digital_receipt_system.entities.Store;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface StoreRepository extends JpaRepository<Store, Long> {
    Optional<Store> findByGstin(String gstin);

    @Query("select new com.backendservice.digital_receipt_system.dto.StoreDto(" +
            "s.id, s.gstin, s.storeName, s.ownerName, s.email, s.phoneNumber, " +
            "s.address, s.city, s.state, s.pincode, s.storeType, s.isActive, s.createdAt, s.updatedAt) " +
            "from Store s where s.gstin = :gstin")
    Optional<com.backendservice.digital_receipt_system.dto.StoreDto> findDtoByGstin(@Param("gstin") String gstin);

    boolean existsByGstin(String gstin);
}