package com.backendservice.digital_receipt_system.listener;

import com.backendservice.digital_receipt_system.events.BillingCreatedEvent;
import com.backendservice.digital_receipt_system.events.BillingStatusEvent;
import com.backendservice.digital_receipt_system.services.BillingApprovalStreamService;
//import com.backendservice.digital_receipt_system.services.PushService;
import com.backendservice.digital_receipt_system.web_sockets.handler.AgentBillingSocketHandler;
import com.backendservice.digital_receipt_system.web_sockets.handler.CustomerBillingSocketHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;

@Component
public class BillingNotificationListener {

//    private final PushService push;
    private final BillingApprovalStreamService stream;
    private final AgentBillingSocketHandler agentBillingSocketHandler;
    private final CustomerBillingSocketHandler customerBillingSocketHandler;
    private final Logger log = LoggerFactory.getLogger(BillingNotificationListener.class);

    public BillingNotificationListener(BillingApprovalStreamService stream, AgentBillingSocketHandler agentBillingSocketHandler, CustomerBillingSocketHandler customerBillingSocketHandler) {
        this.stream = stream;
        this.agentBillingSocketHandler = agentBillingSocketHandler;
        this.customerBillingSocketHandler = customerBillingSocketHandler;
    }

    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void onBillingCreated(BillingCreatedEvent ev) {
        // notify agents via SSE and push
        if (ev.agentIds() != null && !ev.agentIds().isEmpty()) {
            // create a minimal DTO for SSE (re-use existing BillingQueueDto if desired)
            ev.agentIds().forEach(agentId -> agentBillingSocketHandler.notifyAgent(agentId,
                    new com.backendservice.digital_receipt_system.dto.BillingQueueDto(
                            ev.requestId(),
                            ev.customerName(),
                            ev.customerMobile(),
                            ev.grandTotal(),
                            ev.items()
                    )
            ));

            // push to agents (single call)
            try {
//                push.notifyAgents(ev.agentIds(), "New Billing Request", ev.customerName() + " sent a cart");
            } catch (Exception e) {
                log.warn("Failed to push to agents", e);
            }
        }

        // notify customer
//        try {
//            //push.notifyCustomer(ev.customerId(), "Request Created", "Your billing request was created");
//            stream.notifyCustomer(ev.customerId(), ev.requestId(), "CREATED");
//        } catch (Exception e) {
//            log.warn("Failed to notify customer", e);
//        }
    }

    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void onBillingStatusChanged(BillingStatusEvent ev) {
        // notify customer about status (APPROVED/REJECTED)
        try {
            switch (ev.status()) {
                case "APPROVED" -> {
                    //push.notifyCustomer(ev.customerId(), "Approved", "Proceed to payment");
                    customerBillingSocketHandler.notifyCustomer(ev.customerId(), "APPROVED");
                }
                case "REJECTED" -> {
                    //push.notifyCustomer(ev.customerId(), "Rejected", "Your request was rejected");
                    customerBillingSocketHandler.notifyCustomer(ev.customerId(), "REJECTED");
                }
                default -> {
                    //push.notifyCustomer(ev.customerId(), "Update", "Request status: " + ev.status());
                    customerBillingSocketHandler.notifyCustomer(ev.customerId(), ev.status());
                }
            }
        } catch (Exception e) {
            log.warn("Failed to notify customer about status change", e);
        }
    }
}