package com.backendservice.digital_receipt_system.dto;

public record ApiError(String error, String message) {}