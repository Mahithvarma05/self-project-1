package com.backendservice.digital_receipt_system.dto;

import java.time.Instant;
import java.util.Map;

public record CreateStampRequest(Long receiptId, Map<String, Object> metadata) {}
