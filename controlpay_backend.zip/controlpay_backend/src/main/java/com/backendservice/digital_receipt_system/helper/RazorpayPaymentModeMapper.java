package com.backendservice.digital_receipt_system.helper;

import com.backendservice.digital_receipt_system.enums.PaymentMode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Utility mapper for converting Razorpay payment method strings to PaymentMode enum.
 * Adds logging for inputs and the mapping result.
 */
public class RazorpayPaymentModeMapper {

    private static final Logger log = LoggerFactory.getLogger(RazorpayPaymentModeMapper.class);

    public static PaymentMode map(String razorpayMethod) {
        log.debug("Mapping razorpay payment method '{}'", razorpayMethod);
        PaymentMode result = switch (razorpayMethod) {
            case "upi" -> PaymentMode.UPI;
            case "card" -> PaymentMode.CARD;
            case "netbanking" -> PaymentMode.NETBANKING;
            case "wallet" -> PaymentMode.WALLET;
            default -> null;
        };

        if (result == null) {
            log.warn("Unknown Razorpay payment method '{}', returning null", razorpayMethod);
        } else {
            log.debug("Mapped '{}' to PaymentMode.{}", razorpayMethod, result);
        }

        return result;
    }
}