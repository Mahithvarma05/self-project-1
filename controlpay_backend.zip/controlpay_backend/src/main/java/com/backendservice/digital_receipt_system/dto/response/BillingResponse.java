package com.backendservice.digital_receipt_system.dto.response;

public record BillingResponse(
        String status,
        Long approvalId
) {}
