package com.backendservice.digital_receipt_system.exceptions;

public class InvalidCredentialsException extends RuntimeException {
    public InvalidCredentialsException() {
        super("Invalid mobile number or password");
    }
}
