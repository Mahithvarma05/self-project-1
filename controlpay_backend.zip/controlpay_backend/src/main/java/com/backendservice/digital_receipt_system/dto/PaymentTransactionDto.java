package com.backendservice.digital_receipt_system.dto;

import com.backendservice.digital_receipt_system.entities.PaymentTransaction;

import java.time.Instant;

public record PaymentTransactionDto(
    Long id,
    String razorpayPaymentId,
    Long amount,
    String currency,
    String status,
    String method,
    String email,
    String contact,
    Boolean captured,
    Instant createdAt,
    Long paymentOrderId
) {
    public static PaymentTransactionDto from(PaymentTransaction t) {
        Long orderId = null;
        try {
            if (t.getPaymentOrder() != null) orderId = t.getPaymentOrder().getId();
        } catch (Exception ignored) {}
        return new PaymentTransactionDto(
            t.getId(),
            t.getRazorpayPaymentId(),
            t.getAmount(),
            t.getCurrency(),
            t.getStatus(),
            t.getMethod(),
            t.getEmail(),
            t.getContact(),
            t.getCaptured(),
            t.getCreatedAt(),
            orderId
        );
    }
}