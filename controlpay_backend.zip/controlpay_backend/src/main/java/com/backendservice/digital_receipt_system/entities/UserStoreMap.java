package com.backendservice.digital_receipt_system.entities;

import jakarta.persistence.*;
import lombok.Data;

import java.time.Instant;

@Entity
@Table(
    name = "user_store_map",
    uniqueConstraints = @UniqueConstraint(columnNames = {"user_id", "store_gstin"})
)
@Data
public class UserStoreMap {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "store_gstin", nullable = false, length = 15)
    private String storeGstin;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @PrePersist
    public void prePersist() {
        this.createdAt = Instant.now();
    }

}
