package com.backendservice.digital_receipt_system.entities;

import jakarta.persistence.*;

import java.time.Instant;

@Entity
@Table(name = "stores", indexes = {
        @Index(name = "idx_stores_gstin", columnList = "gstin", unique = true)
})
public class Store {
    @Id
    @GeneratedValue(strategy = GenerationType. IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 15)
    private String gstin;

    @Column(nullable = false)
    private String storeName;

    @Column(nullable = false)
    private String ownerName;

    private String email;

    private String phoneNumber;

    @Column(nullable = false)
    private String address;

    private String city;

    private String state;

    @Column(length = 6)
    private String pincode;

    @Column(nullable = false)
    private String storeType; // e.g., RETAIL, WHOLESALE, DISTRIBUTOR

    @Column(nullable = false)
    private Boolean isActive = true;

    private Instant createdAt = Instant.now();

    private Instant updatedAt = Instant.now();

    // Constructors
    public Store() {}

    public Store(String gstin, String storeName, String ownerName, String email,
                 String phoneNumber, String address, String city, String state,
                 String pincode, String storeType) {
        this.gstin = gstin;
        this.storeName = storeName;
        this.ownerName = ownerName;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.address = address;
        this.city = city;
        this.state = state;
        this.pincode = pincode;
        this.storeType = storeType;
    }

    @PrePersist
    public void prePersist() {
        Instant now = Instant.now();
        if (this.createdAt == null) this.createdAt = now;
        if (this.updatedAt == null) this.updatedAt = now;
    }

    @PreUpdate
    public void preUpdate() {
        this.updatedAt = Instant.now();
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getGstin() { return gstin; }
    public void setGstin(String gstin) { this.gstin = gstin; }

    public String getStoreName() { return storeName; }
    public void setStoreName(String storeName) { this.storeName = storeName; }

    public String getOwnerName() { return ownerName; }
    public void setOwnerName(String ownerName) { this.ownerName = ownerName; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this. email = email; }

    public String getPhoneNumber() { return phoneNumber; }
    public void setPhoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }

    public String getState() { return state; }
    public void setState(String state) { this.state = state; }

    public String getPincode() { return pincode; }
    public void setPincode(String pincode) { this.pincode = pincode; }

    public String getStoreType() { return storeType; }
    public void setStoreType(String storeType) { this.storeType = storeType; }

    public Boolean getIsActive() { return isActive; }
    public void setIsActive(Boolean isActive) { this.isActive = isActive; }

    public Instant getCreatedAt() { return createdAt; }
    public void setCreatedAt(Instant createdAt) { this.createdAt = createdAt; }

    public Instant getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(Instant updatedAt) { this.updatedAt = updatedAt; }
}