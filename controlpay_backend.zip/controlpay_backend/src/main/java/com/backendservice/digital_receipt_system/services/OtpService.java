package com.backendservice.digital_receipt_system.services;

import com.backendservice.digital_receipt_system.entities.OtpCode;
import com.backendservice.digital_receipt_system.repositories.OtpCodeRepository;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Locale;
import java.util.Optional;
import java.util.Random;
import java.util.concurrent.TimeUnit;

@Service
public class OtpService {

    private static final Logger log = LoggerFactory.getLogger(OtpService.class);

    private final OtpCodeRepository repo;
    private final Random rnd = new Random();

    // configurable properties
    private final int otpLength;
    private final int expiresInSeconds;
    private final int maxAttempts;
    private final int resendCooldownSeconds;

    // rate limiting quotas
    private final int maxRequestsPerMinute;
    private final int maxRequestsPerHour;

    // Twilio props (optional)
    private final String twilioAccountSid;
    private final String twilioAuthToken;
    private final String twilioFrom;

    // Caffeine caches for rate limiting: key -> count
    private final Cache<String, Integer> phonePerMinute;
    private final Cache<String, Integer> phonePerHour;
    private final Cache<String, Integer> ipPerMinute;
    private final Cache<String, Integer> ipPerHour;

    public OtpService(OtpCodeRepository repo,
                      @Value("${otp.length}") int otpLength,
                      @Value("${otp.expires-seconds}") int expiresInSeconds,
                      @Value("${otp.max-attempts}") int maxAttempts,
                      @Value("${otp.resend-cooldown-seconds}") int resendCooldownSeconds,
                      @Value("${otp.rate.max-per-minute}") int maxRequestsPerMinute,
                      @Value("${otp.rate.max-per-hour}") int maxRequestsPerHour,
                      @Value("${twilio.account-sid}") String twilioAccountSid,
                      @Value("${twilio.auth-token}") String twilioAuthToken,
                      @Value("${twilio.from-number}") String twilioFrom) {
        this.repo = repo;
        this.otpLength = otpLength;
        this.expiresInSeconds = expiresInSeconds;
        this.maxAttempts = maxAttempts;
        this.resendCooldownSeconds = resendCooldownSeconds;
        this.maxRequestsPerMinute = maxRequestsPerMinute;
        this.maxRequestsPerHour = maxRequestsPerHour;
        this.twilioAccountSid = twilioAccountSid;
        this.twilioAuthToken = twilioAuthToken;
        this.twilioFrom = twilioFrom;

        // initialize Twilio if available
        if (twilioAccountSid != null && !twilioAccountSid.isBlank()
                && twilioAuthToken != null && !twilioAuthToken.isBlank()) {
            try {
                Twilio.init(twilioAccountSid, twilioAuthToken);
            } catch (Exception ex) {
                log.warn("Failed to init Twilio: {}", ex.getMessage());
            }
        }

        // Caffeine caches with expirations
        this.phonePerMinute = Caffeine.newBuilder().expireAfterWrite(1, TimeUnit.MINUTES).build();
        this.phonePerHour = Caffeine.newBuilder().expireAfterWrite(1, TimeUnit.HOURS).build();
        this.ipPerMinute = Caffeine.newBuilder().expireAfterWrite(1, TimeUnit.MINUTES).build();
        this.ipPerHour = Caffeine.newBuilder().expireAfterWrite(1, TimeUnit.HOURS).build();
    }

    private String generateNumericOtp(int length) {
        int min = (int) Math.pow(10, length - 1);
        int max = (int) Math.pow(10, length) - 1;
        int v = rnd.nextInt(max - min + 1) + min;
        return String.valueOf(v);
    }

    private void incrementCache(Cache<String, Integer> cache, String key) {
        Integer cur = cache.getIfPresent(key);
        if (cur == null) cache.put(key, 1);
        else cache.put(key, cur + 1);
    }

    private int getCount(Cache<String, Integer> cache, String key) {
        Integer cur = cache.getIfPresent(key);
        return cur == null ? 0 : cur;
    }

    private String normalizeMobile(String m) {
        if (m == null) return null;
        String s = m.trim();
        if (s.startsWith("+")) return s;
        String digits = s.replaceAll("\\D", "");
        // If you prefer E.164, adapt here to prepend country code.
        // Example: if digits length == 10 and country is India, return "+91" + digits
        return digits;
    }

    /**
     * Request an OTP for mobileNumber. supply requestIp (client IP) for rate limiting/audit.
     */
    @Transactional
    public void requestOtp(String mobileNumber, String requestIp) {
        String normalized = normalizeMobile(mobileNumber);

        // Rate limiting: per-phone and per-ip
        if (getCount(phonePerMinute, normalized) >= maxRequestsPerMinute ||
                getCount(phonePerHour, normalized) >= maxRequestsPerHour) {
            log.warn("Rate limit exceeded for phone {} (minute={}, hour={})", normalized,
                    getCount(phonePerMinute, normalized), getCount(phonePerHour, normalized));
            throw new RuntimeException("Too many OTP requests for phone. Try later.");
        }
        if (requestIp != null && (getCount(ipPerMinute, requestIp) >= maxRequestsPerMinute ||
                getCount(ipPerHour, requestIp) >= maxRequestsPerHour)) {
            log.warn("Rate limit exceeded for ip {} (minute={}, hour={})", requestIp,
                    getCount(ipPerMinute, requestIp), getCount(ipPerHour, requestIp));
            throw new RuntimeException("Too many OTP requests from this IP. Try later.");
        }

        // Check resend cooldown
        Optional<OtpCode> lastOpt = repo.findTopByMobileNumberOrderByCreatedAtDesc(normalized);
        if (lastOpt.isPresent()) {
            OtpCode last = lastOpt.get();
            if (!last.getVerified() && Instant.now().isBefore(last.getCreatedAt().plus(resendCooldownSeconds, ChronoUnit.SECONDS))) {
                throw new RuntimeException("Please wait before requesting a new OTP.");
            }
        }

        // generate and hash OTP
        String otp = generateNumericOtp(otpLength);
        String hashed = BCrypt.hashpw(otp, BCrypt.gensalt());

        Instant now = Instant.now();
        Instant exp = now.plus(expiresInSeconds, ChronoUnit.SECONDS);

        OtpCode entry = new OtpCode(normalized, hashed, now, exp, requestIp);
        repo.save(entry);

        // increment rate counters after successful create
        incrementCache(phonePerMinute, normalized);
        incrementCache(phonePerHour, normalized);
        if (requestIp != null) {
            incrementCache(ipPerMinute, requestIp);
            incrementCache(ipPerHour, requestIp);
        }

        // send via Twilio if configured
        try {
            if (twilioAccountSid != null && !twilioAccountSid.isBlank()
                    && twilioAuthToken != null && !twilioAuthToken.isBlank()
                    && twilioFrom != null && !twilioFrom.isBlank()) {

                String msg = String.format(Locale.ENGLISH, "Your OTP is %s. Expires in %d minutes.",
                        otp, Math.max(1, expiresInSeconds / 60));
                Message.creator(new com.twilio.type.PhoneNumber(normalized),
                        new com.twilio.type.PhoneNumber(twilioFrom),
                        msg).create();

                log.info("Sent OTP SMS to {} (ip={})", normalized, requestIp);
            } else {
                // Twilio not configured — log OTP for debug/audit (do not leave this in prod)
                log.info("OTP for {} = {} (not sent; Twilio not configured). ip={}", normalized, otp, requestIp);
            }
        } catch (Exception ex) {
            log.error("Failed to send OTP via Twilio to {}: {}", normalized, ex.getMessage());
            // keep OTP record but bubble up if you prefer
        }
    }

    /**
     * Verify OTP presented by user. supply requestIp for auditing.
     * Returns true if verified successfully.
     */
    @Transactional
    public boolean verifyOtp(String mobileNumber, String code, String requestIp) {
        String normalized = normalizeMobile(mobileNumber);

        OtpCode otp = repo.findTopByMobileNumberOrderByCreatedAtDesc(normalized)
                .orElseThrow(() -> new RuntimeException("No OTP requested for this number"));

        if (otp.getVerified()) {
            log.info("OTP verify attempt for {} but already verified (ip={})", normalized, requestIp);
            throw new RuntimeException("OTP already verified");
        }

        if (otp.getAttempts() >= maxAttempts) {
            log.warn("OTP max attempts exceeded for {} (attempts={}, ip={})", normalized, otp.getAttempts(), requestIp);
            throw new RuntimeException("Maximum verification attempts exceeded");
        }

        if (Instant.now().isAfter(otp.getExpiresAt())) {
            log.info("OTP expired for {} (ip={})", normalized, requestIp);
            throw new RuntimeException("OTP expired");
        }

        otp.setAttempts(otp.getAttempts() + 1);

        boolean ok = BCrypt.checkpw(code.trim(), otp.getCodeHash());
        if (ok) {
            otp.setVerified(true);
            repo.save(otp);
            log.info("OTP verified for {} (ip={})", normalized, requestIp);
            return true;
        } else {
            repo.save(otp);
            log.info("OTP verification failed for {} (attempt={}, ip={})", normalized, otp.getAttempts(), requestIp);
            return false;
        }
    }
}