package com.backendservice.digital_receipt_system.controller;

import com.backendservice.digital_receipt_system.dto.ApiSuccess;
import com.backendservice.digital_receipt_system.dto.request.OtpRequest;
import com.backendservice.digital_receipt_system.dto.request.OtpVerifyRequest;
import com.backendservice.digital_receipt_system.services.OtpService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/v1/otp")
@Validated
public class OtpController {

    private final OtpService otpService;

    public OtpController(OtpService otpService) {
        this.otpService = otpService;
    }

    @PostMapping("/request")
    public ResponseEntity<ApiSuccess> requestOtp(@Valid @RequestBody OtpRequest req, HttpServletRequest servletReq) {
        String ip = extractClientIp(servletReq);
        otpService.requestOtp(req.mobile(), ip);
        return ResponseEntity.ok(new ApiSuccess("OTP_SENT"));
    }

    @PostMapping("/verify")
    public ResponseEntity<ApiSuccess> verifyOtp(@Valid @RequestBody OtpVerifyRequest req, HttpServletRequest servletReq) {
        String ip = extractClientIp(servletReq);
        boolean ok = otpService.verifyOtp(req.mobile(), req.code(), ip);
        return ok ? ResponseEntity.ok(new ApiSuccess("VERIFIED")) :
                     ResponseEntity.ok(new ApiSuccess("INVALID_OTP"));
    }

    private String extractClientIp(HttpServletRequest req) {
        String xf = req.getHeader("X-Forwarded-For");
        if (xf != null && !xf.isBlank()) {
            return xf.split(",")[0].trim();
        }
        return req.getRemoteAddr();
    }
}