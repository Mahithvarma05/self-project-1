package com.backendservice.digital_receipt_system.controller;

import com.backendservice.digital_receipt_system.dto.request.CreateCustomerRequest;
import com.backendservice.digital_receipt_system.dto.response.CustomerResponse;
import com.backendservice.digital_receipt_system.services.CustomerService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/v1/customers")
public class CustomerController {

    private final CustomerService service;

    public CustomerController(CustomerService service) {
        this.service = service;
    }

    @PostMapping("auth/login")
    public ResponseEntity<CustomerResponse> register(@Valid @RequestBody CreateCustomerRequest req) {
        return ResponseEntity.ok(service.createOrGet(req));
    }
}
