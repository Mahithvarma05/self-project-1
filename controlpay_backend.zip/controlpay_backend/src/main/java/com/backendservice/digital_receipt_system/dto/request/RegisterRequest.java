package com.backendservice.digital_receipt_system.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

/**
 * Registration request payload.
 *
 * Extended with optional Aadhaar and PAN for eKYC verification.
 */
public record RegisterRequest(
    @NotBlank(message = "name is required") String name,

    @NotBlank(message = "mobile is required")
    @Pattern(regexp = "^[+\\d][\\d\\s\\-()]{6,}$", message = "invalid mobile format") String mobile,

    @NotBlank(message = "password is required")
    @Size(min = 6, message = "password must be at least 6 characters") String password,

    // optional - include one or both if you want verification
    String aadhaar,
    String pan
) {}