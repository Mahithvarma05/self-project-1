package com.backendservice.digital_receipt_system.services;

import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;

@Service
public class PaymentService {

    private final RazorpayClient razorpayClient;
    private final String razorpaySecret;
    private final String webhookSecret;


    public PaymentService(RazorpayClient razorpayClient, @Value("${razorpay.key-secret}") String razorpaySecret, @Value("${razorpay.webhook.secret}") String webhookSecret) {
        this.razorpayClient = razorpayClient;
        this.razorpaySecret = razorpaySecret;
        this.webhookSecret = webhookSecret;
    }

    /**
     * Create Razorpay order.
     * amountRupees: amount in rupees (decimal). Razorpay expects amount in paise (integer).
     */
    public Order createOrder(BigDecimal amountRupees, String currency, String receipt) throws Exception {
        long amountPaise = amountRupees
                .multiply(new BigDecimal(100))
                .setScale(0, RoundingMode.HALF_UP)
                .longValueExact();

        JSONObject orderRequest = new JSONObject();
        orderRequest.put("amount", amountPaise);
        orderRequest.put("currency", currency != null ? currency : "INR");
        orderRequest.put("receipt", receipt != null ? receipt : "rcpt_" + System.currentTimeMillis());
        orderRequest.put("payment_capture", 1);

        return razorpayClient.orders.create(orderRequest);
    }

    /**
     * Verify Razorpay signature for webhooks or client-side order verification.
     * For webhook verification: compute HMAC_SHA256(body, secret) and compare base64 string or hex.
     * Razorpay sends signature as hex string (lowercase) in X-Razorpay-Signature for webhooks.
     */
    private static boolean constantTimeEquals(byte[] a, byte[] b) {
        if (a == null || b == null || a.length != b.length) return false;
        int result = 0;
        for (int i = 0; i < a.length; i++) result |= a[i] ^ b[i];
        return result == 0;
    }

    public boolean verifyClientSignature(String payload, String signature) {
        return verify(payload, razorpaySecret, signature);
    }

    public boolean verifyWebhookSignature(String payload, String signature) {
        return verify(payload, webhookSecret, signature);
    }

    private boolean verify(String payload, String secret, String signature) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
            byte[] hash = mac.doFinal(payload.getBytes(StandardCharsets.UTF_8));
            return bytesToHex(hash).equalsIgnoreCase(signature);
        } catch (Exception e) {
            return false;
        }
    }

    private byte[] hexStringToBytes(String hex) {
        if (hex == null || hex.length() % 2 != 0) return null;
        int len = hex.length();
        byte[] out = new byte[len/2];
        try {
            for (int i = 0; i < len; i += 2) {
                out[i/2] = (byte) ((Character.digit(hex.charAt(i), 16) << 4)
                        + Character.digit(hex.charAt(i+1), 16));
            }
            return out;
        } catch (Exception ex) { return null; }
    }

    private static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }
}