package com.backendservice.digital_receipt_system.dto;

import java.math.BigDecimal;
import java.util.List;

public record BillingQueueDto(
        Long requestId,
        String customerName,
        String customerMobile,
        BigDecimal grandTotal,
        List<BillingItemView> items
) {}
