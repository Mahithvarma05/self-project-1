package com.backendservice.digital_receipt_system.repositories;

import com.backendservice.digital_receipt_system.entities.BillingRequest;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

public interface BillingRequestRepository extends JpaRepository<BillingRequest, Long> {

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select b from BillingRequest b where b.id=:id")
    BillingRequest lock(@Param("id") Long id);

    @Query("select b from BillingRequest b where b.gstin=:gstin and b.status='PENDING'")
    List<BillingRequest> pendingForStore(@Param("gstin") String gstin);

    @Modifying
    @Query("update BillingRequest b set b.status='EXPIRED' where b.status='PENDING' and b.expiresAt < :now")
    int expireNow(@Param("now") Instant now);

    Optional<BillingRequest>
    findTopByCustomerIdAndGstinAndStatusOrderByExpiresAtDesc(
            Long customerId,
            String gstin,
            BillingRequest.Status status
    );

    Optional<BillingRequest>
    findTopByCustomerIdAndGstinOrderByCreatedAtDesc(
            Long customerId,
            String gstin
    );

}
