package com.backendservice.digital_receipt_system.services;


import com.backendservice.digital_receipt_system.entities.PaymentOrder;
import com.backendservice.digital_receipt_system.entities.PaymentTransaction;
import com.backendservice.digital_receipt_system.repositories.PaymentOrderRepository;
import com.backendservice.digital_receipt_system.repositories.PaymentTransactionRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.Optional;

@Service
@Slf4j
public class PaymentPersistenceService {

    private final PaymentOrderRepository orderRepository;
    private final PaymentTransactionRepository transactionRepository;
    private final ObjectMapper objectMapper;
    private final ParkingSessionService parkingSessionService;

    public PaymentPersistenceService(PaymentOrderRepository orderRepository,
                                     PaymentTransactionRepository transactionRepository,
                                     ObjectMapper objectMapper, ParkingSessionService parkingSessionService) {
        this.orderRepository = orderRepository;
        this.transactionRepository = transactionRepository;
        this.objectMapper = objectMapper;
        this.parkingSessionService = parkingSessionService;
    }

    /**
     * Persist an order returned by Razorpay createOrder.
     * Input is the JSON string (order.toJson()) or JsonNode.
     */
    @Transactional
    public PaymentOrder saveOrderJson(String orderJson) {
        try {
            JsonNode n = objectMapper.readTree(orderJson);
            String razorpayOrderId = n.path("id").asText();
            long amount = n.path("amount").asLong(0);
            String currency = n.path("currency").asText(null);
            String receipt = n.path("receipt").asText(null);
            String status = n.path("status").asText(null);
            String paymentMode = n.path("method").asText(null);

            Optional<PaymentOrder> opt = orderRepository.findByRazorpayOrderId(razorpayOrderId);
            PaymentOrder order = opt.orElseGet(PaymentOrder::new);

            order.setRazorpayOrderId(razorpayOrderId);
            order.setAmount(amount);
            order.setCurrency(currency);
            order.setReceipt(receipt);
            order.setStatus(status);
//            order.setPaymentMode(paymentMode);
            order.setAmountPaid(n.path("amount_paid").asLong(0));
            order.setAmountDue(n.path("amount_due").asLong(0));
            order.setUpdatedAt(Instant.now());
            if (order.getCreatedAt() == null) {
                order.setCreatedAt(Instant.now());
            }
            return orderRepository.save(order);
        } catch (Exception e) {
            throw new RuntimeException("Failed to parse/save order JSON", e);
        }
    }

    /**
     * Process webhook event payload (raw JSON body). Will create/update PaymentTransaction and PaymentOrder accordingly.
     */
    @Retryable(
            retryFor = Exception.class,
            maxAttempts = 3,
            backoff = @Backoff(delay = 1000, multiplier = 2)
    )
    @Transactional
    public void processWebhookEvent(String bodyJson) {

        try {
            JsonNode root = objectMapper.readTree(bodyJson);
            String event = root.path("event").asText("");

            // Payment event
            JsonNode payment = root.path("payload").path("payment").path("entity");
            if (!payment.isMissingNode()) {
                handlePaymentEvent(event, payment);
                return;
            }

            if (!payment.isMissingNode()) {

                String paymentId = payment.path("id").asText(null);
                if (paymentId == null) return;

                // ---- Idempotency ----
                if (transactionRepository.existsByRazorpayPaymentId(paymentId)) {
                    log.info("Duplicate webhook ignored: {}", paymentId);
                    return;
                }

                handlePaymentEvent(event, payment);
                return;
            }

            // Order event
            JsonNode orderEntity = root.path("payload").path("order").path("entity");
            if (!orderEntity.isMissingNode()) {
                handleOrderEvent(orderEntity);
            }

        } catch (Exception e) {
            throw new RuntimeException("Webhook parse/save failed", e);
        }
    }


    private void handleOrderEvent(JsonNode orderNode) {

        String orderId = orderNode.path("id").asText(null);
        if (orderId == null) {
            throw new IllegalArgumentException("Invalid webhook payload: missing order.id");
        }

        long amount      = orderNode.path("amount").asLong(0);       // total order amount (paise)
        String currency  = orderNode.path("currency").asText(null);
        String receipt   = orderNode.path("receipt").asText(null);
        String status    = orderNode.path("status").asText(null);
        String paymentMode = orderNode.path("method").asText(null);

        long amountPaid  = orderNode.path("amount_paid").asLong(0);  // paise
        long amountDue   = orderNode.path("amount_due").asLong(0);   // paise

        // 1 Fetch or create PaymentOrder (idempotent)
        PaymentOrder order = orderRepository
                .findByRazorpayOrderId(orderId)
                .orElseGet(() -> {
                    PaymentOrder o = new PaymentOrder();
                    o.setRazorpayOrderId(orderId);
                    o.setCreatedAt(Instant.now());
                    return o;
                });

        // 2 Update order fields safely
        order.setAmount(amount);          // total order amount (paise)
        order.setCurrency(currency);
        order.setReceipt(receipt);
        order.setStatus(status);
//        order.setPaymentMode(paymentMode);
        order.setAmountPaid(amountPaid);
        order.setAmountDue(amountDue);
        order.setUpdatedAt(Instant.now());

        // 3 Auto-capture friendly business logic
        if ("paid".equalsIgnoreCase(status) && amountDue == 0) {
            order.setStatus("paid");  // ensure correct normalized status
        } else if (amountPaid > 0 && amountDue > 0) {
            order.setStatus("partially_paid");
        } else {
            // Keep Razorpay status: created, attempted, failed, etc.
            order.setStatus(status);
        }

        // 4 Save final state
        orderRepository.save(order);
    }

    @Recover
    public void recoverWebhook(Exception ex, String bodyJson) {
        log.error("Webhook permanently failed after retries", ex);
    }

    private void handlePaymentEvent(String event, JsonNode payment) {

        String paymentId = payment.path("id").asText(null);
        String orderId   = payment.path("order_id").asText(null);
        String method    = payment.path("method").asText(null);
        String status    = payment.path("status").asText(null);
        long amount      = payment.path("amount").asLong(0);

        if (paymentId == null || orderId == null) return;

        PaymentOrder order = orderRepository
                .findByRazorpayOrderId(orderId)
                .orElseThrow(() -> new RuntimeException("Unknown order"));

        // ... existing validation code ...

        // Accept only CAPTURED payments
        if (!"captured".equalsIgnoreCase(status)) {
            log.warn("Ignoring non-captured payment {}", paymentId);
            return;
        }

        // Create transaction
        PaymentTransaction tx = new PaymentTransaction();
        tx.setRazorpayPaymentId(paymentId);
        tx.setPaymentOrder(order);
        tx.setAmount(amount);
        tx.setCurrency(order.getCurrency());
        tx.setStatus("SUCCESS");
        tx.setCaptured(true);
        tx.setMethod(method);
        tx.setCreatedAt(Instant.now());
        transactionRepository.save(tx);

        // Mark order PAID
        order.setStatus("PAID");
        long paid = order.getAmountPaid() == null ? 0L : order.getAmountPaid();
        order.setAmountPaid(paid + amount);
        order.setAmountDue(Math.max(0L, order.getAmount() - order.getAmountPaid()));
        order.setUpdatedAt(Instant.now());
        orderRepository.save(order);

        // check if this is a parking payment and complete session**
        String receipt = order.getReceipt();
        if (receipt != null && receipt.startsWith("parking-")) {
            try {
                Long sessionId = Long.parseLong(receipt.substring(8));
                parkingSessionService.completePayment(sessionId, orderId);
            } catch (Exception e) {
                log.error("Failed to complete parking session", e);
            }
        }

        log.info("Order {} marked PAID via {}", orderId, method);
    }

}