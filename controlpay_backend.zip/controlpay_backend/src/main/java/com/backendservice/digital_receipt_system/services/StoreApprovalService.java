package com.backendservice.digital_receipt_system.services;

import com.backendservice.digital_receipt_system.dto.ApprovalQueueDto;
import com.backendservice.digital_receipt_system.dto.ApprovalStatusDto;
import com.backendservice.digital_receipt_system.dto.response.ApprovalResponse;
import com.backendservice.digital_receipt_system.entities.ApprovalRequest;
import com.backendservice.digital_receipt_system.entities.User;
import com.backendservice.digital_receipt_system.exceptions.StoreNotFoundException;
import com.backendservice.digital_receipt_system.repositories.ApprovalRepository;
import com.backendservice.digital_receipt_system.repositories.StoreRepository;
import com.backendservice.digital_receipt_system.repositories.UserRepository;
import com.backendservice.digital_receipt_system.repositories.UserStoreMapRepository;
import com.backendservice.digital_receipt_system.web_sockets.handler.AdminApprovalSocket;
import com.backendservice.digital_receipt_system.web_sockets.handler.CustomerStoreApprovalSocketHandler;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

@Service
public class StoreApprovalService {

    private final ApprovalRepository approvalRepo;
    private final StoreRepository storeRepo;
    private final UserStoreMapRepository mapRepo;
//    private final PushService pushService;
    private final ApprovalStreamService streamService;
    private final UserRepository userRepo;
    private final CustomerApprovalStreamService customerStreamService;
    private final CustomerStoreApprovalSocketHandler customerStoreApprovalSocketHandler;
    private final AdminApprovalSocket adminApprovalSocket;

    public StoreApprovalService(ApprovalRepository approvalRepo, StoreRepository storeRepo, UserStoreMapRepository mapRepo, ApprovalStreamService streamService, UserRepository userRepo, CustomerApprovalStreamService customerStreamService, CustomerStoreApprovalSocketHandler customerStoreApprovalSocketHandler, AdminApprovalSocket adminApprovalSocket) {
        this.approvalRepo = approvalRepo;
        this.storeRepo = storeRepo;
        this.mapRepo = mapRepo;
        this.streamService = streamService;
        this.userRepo = userRepo;
        this.customerStreamService = customerStreamService;
        this.customerStoreApprovalSocketHandler = customerStoreApprovalSocketHandler;
        this.adminApprovalSocket = adminApprovalSocket;
    }

    @Transactional
    public ApprovalResponse requestApproval(Long customerId, String gstin) {

        if (!storeRepo.existsByGstin(gstin))
            throw new StoreNotFoundException(gstin);

        approvalRepo.expirePending(Instant.now());

        Optional<ApprovalRequest> active =
                approvalRepo.findTopByCustomerIdAndStoreGstinAndStatusOrderByCreatedAtDesc(
                        customerId, gstin, "PENDING");

        if (active.isPresent()) {
            return new ApprovalResponse("ALREADY_PENDING", active.get().getId());
        }

        ApprovalRequest req = approvalRepo.save(new ApprovalRequest(customerId, gstin));

        notifyAdmins(req, customerId, gstin);

        return new ApprovalResponse("CREATED", req.getId());
    }

    @Transactional
    public void approve(Long requestId) {

        ApprovalRequest req = approvalRepo.findByCustomerIdAndStatus(requestId, "PENDING")
                .orElseThrow(() -> new RuntimeException("Request not found or already processed"));

        req.setStatus("APPROVED");
        req.setUpdatedAt(Instant.now());
        approvalRepo.save(req);

        //realtime SSE
//        customerStreamService.notifyCustomer(req.getCustomerId(), "APPROVED");
        customerStoreApprovalSocketHandler.notifyCustomer(req.getCustomerId(), "APPROVED");


//        pushService.notifyCustomer(req.getCustomerId(),
//                "Approved",
//                "Your shopping request has been approved");
    }


    @Transactional
    public void reject(Long requestId) {

        ApprovalRequest req = approvalRepo.findByCustomerIdAndStatus(requestId, "PENDING")
                .orElseThrow(() -> new RuntimeException("Request not found or already processed"));

        req.setStatus("REJECTED");
        req.setUpdatedAt(Instant.now());
        approvalRepo.save(req);

//        customerStreamService.notifyCustomer(req.getCustomerId(), "REJECTED");
        customerStoreApprovalSocketHandler.notifyCustomer(req.getCustomerId(),"REJECTED");

//        pushService.notifyCustomer(req.getCustomerId(),
//                "Rejected",
//                "Your shopping request has been rejected");
    }

    @Transactional(readOnly = true)
    public List<ApprovalQueueDto> pendingForAdmin(String key) {

        User admin = userRepo.findBySseKey(key)
                .orElseThrow(() -> new RuntimeException("Invalid access key"));

        if (!admin.getRole().equals("ADMIN"))
            throw new RuntimeException("Access denied");

        String gstin = mapRepo.findStoreForUser(admin.getId()).get();

        return approvalRepo.findPendingByStore(gstin);
    }

    @Transactional(readOnly = true)
    public ApprovalStatusDto status(String key, Long Id) {

        User customer = userRepo.findBySseKey(key)
                .orElseThrow(() -> new RuntimeException("Invalid key"));

        return approvalRepo
                .findById(Id)
                .map(r -> new ApprovalStatusDto(r.getStatus()))
                .orElse(new ApprovalStatusDto("NO_REQUEST"));
    }


    private void notifyAdmins(ApprovalRequest req, Long customerId, String gstin) {

        List<Long> adminIds = mapRepo.findAdminsForStore(gstin);

        User customer = userRepo.findById(customerId).orElseThrow();

        String title = "New customer approval request";
        String message = "Customer " + customer.getName() + " is requesting access";

        // realtime SSE
        ApprovalQueueDto dto = new ApprovalQueueDto(
                req.getId(),
                customer.getName(),
                customer.getMobileNumber(),
                req.getCreatedAt(),
                req.getCustomerId()
        );

//        adminIds.forEach(id -> streamService.notifyAdmin(id, dto));  //SSE
        adminIds.forEach(id -> adminApprovalSocket.push(id, dto)); // WebSocket

        // push notification
//        pushService.notifyAdmins(adminIds, title, message);
    }

}
