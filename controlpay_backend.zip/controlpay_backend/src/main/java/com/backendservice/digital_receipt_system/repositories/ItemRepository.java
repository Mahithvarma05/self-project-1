package com.backendservice.digital_receipt_system.repositories;

import com.backendservice.digital_receipt_system.dto.ItemDto;
import com.backendservice.digital_receipt_system.dto.ItemListDto;
import com.backendservice.digital_receipt_system.dto.ItemLiteDto;
import com.backendservice.digital_receipt_system.entities.Item;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface ItemRepository extends JpaRepository<Item, Long> {
    Optional<Item> findByBarcode(String barcode);

    @Query("""
    SELECT new com.backendservice.digital_receipt_system.dto.ItemListDto(
        i.id, i.barcode, i.name, i.price, i.gstPercentage
    )
    FROM Item i
    ORDER BY i.id DESC
""")
    List<ItemListDto> findAllItemsFast();

    /**
     * Projection-based bulk fetch to return only the fields used in billing calculations.
     */
    @Query("""
      SELECT new com.backendservice.digital_receipt_system.dto.ItemLiteDto(
        i.id, i.name, i.price, i.gstPercentage
      )
      FROM Item i
      WHERE i.id IN :ids
    """)
    List<ItemLiteDto> findAllLiteByIdIn(@Param("ids") List<Long> ids);
}