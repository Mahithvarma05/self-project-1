package com.backendservice.digital_receipt_system.dto.response;

/**
 * Registration response returned to client.
 *
 * Fields:
 * - userId: created user's DB id (nullable on error)
 * - name: user name (nullable on error)
 * - role: assigned role (nullable on error)
 * - accessKey: SSE/access key (nullable on error)
 * - message: informational status or error message
 */
public record RegisterResponse(
    Long userId,
    String name,
    String role,
    String accessKey,
    String message
) {}