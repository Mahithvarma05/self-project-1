package com.backendservice.digital_receipt_system.entities;

import jakarta.persistence.*;
import lombok.Data;
import java.time.Instant;

@Entity
@Table(name = "parking_areas")
@Data
public class ParkingArea {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "area_code", nullable = false, unique = true, length = 50)
    private String areaCode; // Unique identifier for QR code
    
    @Column(nullable = false)
    private String name;
    
    @Column(name = "merchant_gstin", nullable = false, length = 15)
    private String merchantGstin;
    
    @Column(name = "location_address")
    private String locationAddress;
    
    @Column(name = "hourly_rate", nullable = false)
    private Integer hourlyRate; // in rupees
    
    @Column(name = "total_capacity")
    private Integer totalCapacity;
    
    @Column(name = "is_active", nullable = false)
    private Boolean isActive = true;
    
    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;
    
    @Column(name = "updated_at")
    private Instant updatedAt;
    
    @PrePersist
    public void prePersist() {
        Instant now = Instant.now();
        if (this.createdAt == null) this.createdAt = now;
        if (this.updatedAt == null) this.updatedAt = now;
    }
    
    @PreUpdate
    public void preUpdate() {
        this.updatedAt = Instant.now();
    }
}