package com.backendservice.digital_receipt_system.repositories;

import com.backendservice.digital_receipt_system.entities.ParkingSession;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.time.Instant;
import java.util.List;
import java.util.Optional;

public interface ParkingSessionRepository extends JpaRepository<ParkingSession, Long> {
    
    Optional<ParkingSession> findBySessionCode(String sessionCode);
    
    @Query("SELECT ps FROM ParkingSession ps WHERE ps.userId = :userId AND ps.status = 'ACTIVE'")
    Optional<ParkingSession> findActiveSessionByUserId(Long userId);
    
    @Query("SELECT ps FROM ParkingSession ps WHERE ps.userId = :userId AND ps.status IN ('ACTIVE', 'PENDING_PAYMENT')")
    List<ParkingSession> findActiveOrPendingSessionsByUserId(Long userId);
    
    Page<ParkingSession> findByUserId(Long userId, Pageable pageable);
    
    Page<ParkingSession> findByParkingAreaId(Long parkingAreaId, Pageable pageable);
    
    @Query("SELECT ps FROM ParkingSession ps WHERE ps.parkingAreaId = :parkingAreaId AND ps.startTime BETWEEN :from AND :to")
    Page<ParkingSession> findByParkingAreaIdAndDateRange(Long parkingAreaId, Instant from, Instant to, Pageable pageable);
    
    @Query("SELECT COUNT(ps) FROM ParkingSession ps WHERE ps.parkingAreaId = :parkingAreaId AND ps.status = 'ACTIVE'")
    Long countActiveSessionsByParkingArea(Long parkingAreaId);
}