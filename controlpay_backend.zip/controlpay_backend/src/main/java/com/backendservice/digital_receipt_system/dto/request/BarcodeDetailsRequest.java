package com.backendservice.digital_receipt_system.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;


public class BarcodeDetailsRequest {
    @NotBlank
    @Pattern(regexp = "^[A-Za-z0-9\\-]{1,64}$", message = "invalid barcode format")
    private String barcode;

    public BarcodeDetailsRequest() {}
    public BarcodeDetailsRequest(String barcode) { this.barcode = barcode; }

    public String getBarcode() { return barcode; }
    public void setBarcode(String barcode) { this.barcode = barcode; }
}