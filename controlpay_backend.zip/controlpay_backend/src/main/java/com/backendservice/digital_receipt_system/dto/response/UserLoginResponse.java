package com.backendservice.digital_receipt_system.dto.response;

public record UserLoginResponse(
    Long userId,
    String name,
    String role,
    String storeGstin,
    String accessKey
) {}
