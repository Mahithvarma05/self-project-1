package com.backendservice.digital_receipt_system.repositories;

import com.backendservice.digital_receipt_system.entities.PaymentTransaction;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

public interface PaymentTransactionRepository extends JpaRepository<PaymentTransaction, Long> {
    Optional<PaymentTransaction> findByRazorpayPaymentId(String razorpayPaymentId);

    boolean existsByRazorpayPaymentId(String paymentId);

    // Pageable/time-range queries for audits
    Page<PaymentTransaction> findByCreatedAtBetween(Instant from, Instant to, Pageable pageable);
    Page<PaymentTransaction> findByCreatedAtGreaterThanEqual(Instant from, Pageable pageable);
    Page<PaymentTransaction> findByCreatedAtLessThanEqual(Instant to, Pageable pageable);

    List<PaymentTransaction> findTop5ByContactOrderByCreatedAtDesc(String contact);
}
