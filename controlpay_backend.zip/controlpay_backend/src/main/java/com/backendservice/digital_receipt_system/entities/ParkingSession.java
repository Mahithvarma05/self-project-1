package com.backendservice.digital_receipt_system.entities;

import jakarta.persistence.*;
import lombok.Data;
import java.math.BigDecimal;
import java.time.Instant;

@Entity
@Table(name = "parking_sessions",
       indexes = {
           @Index(name = "idx_parking_sessions_user_id", columnList = "user_id"),
           @Index(name = "idx_parking_sessions_status", columnList = "status"),
           @Index(name = "idx_parking_sessions_parking_area_id", columnList = "parking_area_id")
       })
@Data
public class ParkingSession {
    
    public enum Status {
        ACTIVE,
        PENDING_PAYMENT,
        PAID,
        COMPLETED,
        CANCELLED,
        EXPIRED
    }
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "session_code", nullable = false, unique = true, length = 50)
    private String sessionCode; // Unique identifier for the session
    
    @Column(name = "user_id", nullable = false)
    private Long userId;
    
    @Column(name = "vehicle_id")
    private Long vehicleId;
    
    @Column(name = "parking_area_id", nullable = false)
    private Long parkingAreaId;
    
    @Column(name = "vehicle_type", nullable = false, length = 20)
    private String vehicleType;
    
    @Column(name = "number_plate", nullable = false, length = 20)
    private String numberPlate;
    
    @Column(name = "start_time", nullable = false)
    private Instant startTime;
    
    @Column(name = "exit_time")
    private Instant exitTime;
    
    @Column(name = "end_time")
    private Instant endTime;
    
    @Column(name = "duration_minutes")
    private Long durationMinutes;
    
    @Column(name = "hourly_rate", nullable = false)
    private Integer hourlyRate;
    
    @Column(name = "total_amount", precision = 12, scale = 2)
    private BigDecimal totalAmount;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 20)
    private Status status;
    
    @Column(name = "payment_order_id")
    private Long paymentOrderId;
    
    @Column(name = "razorpay_order_id", length = 128)
    private String razorpayOrderId;
    
    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;
    
    @Column(name = "updated_at")
    private Instant updatedAt;
    
    @PrePersist
    public void prePersist() {
        Instant now = Instant.now();
        if (this.createdAt == null) this.createdAt = now;
        if (this.updatedAt == null) this.updatedAt = now;
        if (this.sessionCode == null) {
            this.sessionCode = generateSessionCode();
        }
    }
    
    @PreUpdate
    public void preUpdate() {
        this.updatedAt = Instant.now();
    }
    
    private String generateSessionCode() {
        return "PS-" + System.currentTimeMillis() + "-" + 
               (int)(Math.random() * 10000);
    }
}