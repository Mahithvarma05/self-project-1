package com.backendservice.digital_receipt_system.dto;

public record ApiSuccess(String message) {}