package com.backendservice.digital_receipt_system.services;

import com.backendservice.digital_receipt_system.dto.ItemDto;
import com.backendservice.digital_receipt_system.dto.ItemListDto;
import com.backendservice.digital_receipt_system.entities.Item;
import com.backendservice.digital_receipt_system.exceptions.ItemNotFoundException;
import com.backendservice.digital_receipt_system.repositories.ItemRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Slf4j
public class ItemService {
    private final ItemRepository repository;

    public ItemService(ItemRepository repository) {
        this.repository = repository;
    }

    @Transactional(readOnly = true)
    @Cacheable(value = "itemByBarcode", key = "#barcode")
    public ItemDto findByBarcode(String barcode) {
        log.info("Searching DB for barcode={}", barcode);
        return map(repository.findByBarcode(barcode)
                .orElseThrow(() -> new ItemNotFoundException(barcode)));
    }

    private ItemDto map(Item item) {
        return new ItemDto(
                item.getId(),
                item.getBarcode(),
                item.getName(),
                item.getPrice(),
                item.getGstPercentage(),
                item.getGstAmount(),
                item.getPriceWithGst()
        );
    }

    @Transactional(readOnly = true)
    public List<ItemListDto> allItems() {
        return repository.findAllItemsFast();
    }

}