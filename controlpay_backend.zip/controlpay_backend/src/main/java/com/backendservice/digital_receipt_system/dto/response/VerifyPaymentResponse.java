package com.backendservice.digital_receipt_system.dto.response;

import lombok.Data;

@Data
public class VerifyPaymentResponse {
    private String status;

    public VerifyPaymentResponse(String status) {
        this.status = status;
    }

    public static VerifyPaymentResponse success() {
        return new VerifyPaymentResponse("VERIFIED");
    }

    public static VerifyPaymentResponse failed() {
        return new VerifyPaymentResponse("INVALID_SIGNATURE");
    }

}
