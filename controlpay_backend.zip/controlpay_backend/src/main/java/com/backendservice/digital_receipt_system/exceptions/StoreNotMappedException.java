package com.backendservice.digital_receipt_system.exceptions;

public class StoreNotMappedException extends RuntimeException {
    public StoreNotMappedException() {
        super("User is not mapped to any store");
    }
}
