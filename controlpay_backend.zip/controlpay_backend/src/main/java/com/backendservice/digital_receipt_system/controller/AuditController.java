package com.backendservice.digital_receipt_system.controller;

import com.backendservice.digital_receipt_system.dto.PaymentTransactionDto;
import com.backendservice.digital_receipt_system.entities.PaymentTransaction;
import com.backendservice.digital_receipt_system.entities.User;
import com.backendservice.digital_receipt_system.repositories.PaymentTransactionRepository;
import com.backendservice.digital_receipt_system.repositories.UserRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/v1/audits")
public class AuditController {

    private final UserRepository userRepo;
    private final PaymentTransactionRepository txRepo;

    public AuditController(UserRepository userRepo, PaymentTransactionRepository txRepo) {
        this.userRepo = userRepo;
        this.txRepo = txRepo;
    }

    /**
     * GET /v1/audits/transactions
     * Headers:
     *   X-ACCESS-KEY: user's SSE/access key
     *
     * Query params:
     *   from (optional) - ISO-8601 instant (inclusive)
     *   to   (optional) - ISO-8601 instant (inclusive)
     *   page (optional) - page index (default 0)
     *   size (optional) - page size (default 50, capped at 200)
     */
    @GetMapping("/transactions")
    public ResponseEntity<Page<PaymentTransactionDto>> transactions(
            @RequestHeader("X-ACCESS-KEY") String key,
            @RequestParam(required = false) String from,
            @RequestParam(required = false) String to,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "50") int size
    ) {
        User user = userRepo.findBySseKey(key)
                .orElseThrow(() -> new RuntimeException("Invalid access key"));

        String role = user.getRole();

        // Support both DB conventions seen in the codebase
        boolean isCa = "CA".equals(role) || "ROLE_CA".equals(role);
        boolean isAdmin = "ADMIN".equals(role) || "ROLE_MERCHANT_ADMIN".equals(role);

        if (!isCa && !isAdmin) {
            throw new RuntimeException("Access denied");
        }

        int cappedSize = Math.min(Math.max(1, size), 200);
        // Sort by createdAt descending (most recent first)
        Pageable pageable = PageRequest.of(
                Math.max(0, page),
                cappedSize,
                Sort.by(Sort.Direction.DESC, "createdAt")
        );

        Instant fromInstant = null;
        Instant toInstant = null;
        try {
            if (from != null && !from.isBlank()) {
                fromInstant = Instant.parse(from);
            }
            if (to != null && !to.isBlank()) {
                toInstant = Instant.parse(to);
            }
        } catch (Exception ex) {
            throw new RuntimeException("Invalid instant format for 'from' or 'to'. Use ISO-8601 format (e.g., 2024-01-15T10:30:00Z)");
        }

        Page<PaymentTransaction> pageResult;

        if (fromInstant != null && toInstant != null) {
            // Both dates provided
            pageResult = txRepo.findByCreatedAtBetween(fromInstant, toInstant, pageable);
        } else if (fromInstant != null) {
            // Only 'from' provided - get from that date until now
            pageResult = txRepo.findByCreatedAtGreaterThanEqual(fromInstant, pageable);
        } else if (toInstant != null) {
            // Only 'to' provided - get all transactions up to that date
            pageResult = txRepo.findByCreatedAtLessThanEqual(toInstant, pageable);
        } else {
            // No date filters - get all transactions
            pageResult = txRepo.findAll(pageable);
        }

        Page<PaymentTransactionDto> dtoPage = pageResult.map(PaymentTransactionDto::from);
        return ResponseEntity.ok(dtoPage);
    }
}