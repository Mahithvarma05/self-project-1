package com.backendservice.digital_receipt_system.config;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

/**
 * Diagnostic filter to log incoming request method, scheme, URI and forwarded headers.
 * Deploy this temporarily to gather evidence of redirects/proxy behavior.
 */
@Component
public class RequestLoggingFilter extends OncePerRequestFilter {

    private static final Logger log = LoggerFactory.getLogger(RequestLoggingFilter.class);

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {
        try {
            log.info("Incoming request: method={}, scheme={}, uri={}, X-Forwarded-Proto={}, X-Forwarded-For={}, Host={}",
                    request.getMethod(),
                    request.getScheme(),
                    request.getRequestURI(),
                    request.getHeader("X-Forwarded-Proto"),
                    request.getHeader("X-Forwarded-For"),
                    request.getHeader("Host"));
        } catch (Exception ex) {
            log.warn("Failed to log incoming request", ex);
        }
        filterChain.doFilter(request, response);
    }
}