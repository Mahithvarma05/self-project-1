package com.backendservice.digital_receipt_system.controller;

import com.backendservice.digital_receipt_system.dto.ApiSuccess;
import com.backendservice.digital_receipt_system.dto.ApprovalQueueDto;
import com.backendservice.digital_receipt_system.dto.request.CustomerApprovalRequest;
import com.backendservice.digital_receipt_system.dto.request.GstinRequest;
import com.backendservice.digital_receipt_system.dto.request.UserLoginRequest;
import com.backendservice.digital_receipt_system.dto.response.ApprovalResponse;
import com.backendservice.digital_receipt_system.dto.response.UserLoginResponse;
import com.backendservice.digital_receipt_system.entities.User;
import com.backendservice.digital_receipt_system.repositories.UserRepository;
import com.backendservice.digital_receipt_system.services.ApprovalStreamService;
import com.backendservice.digital_receipt_system.services.CustomerApprovalStreamService;
import com.backendservice.digital_receipt_system.services.StoreApprovalService;
import com.backendservice.digital_receipt_system.services.UserAuthService;
import jakarta.validation.Valid;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.util.List;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/v1/merchants")
public class MerchantController {

    private final UserAuthService authService;
    private final StoreApprovalService approvalService;
    private final ApprovalStreamService approvalStreamService;
    private final CustomerApprovalStreamService customerApprovalStreamService;
    private final UserRepository userRepo;

    public MerchantController(UserAuthService authService, StoreApprovalService approvalService, ApprovalStreamService approvalStreamService, CustomerApprovalStreamService customerApprovalStreamService, UserRepository userRepo) {
        this.authService = authService;
        this.approvalService = approvalService;
        this.approvalStreamService = approvalStreamService;
        this.customerApprovalStreamService = customerApprovalStreamService;
        this.userRepo = userRepo;
    }

    @PostMapping("/auth/login")
    public ResponseEntity<UserLoginResponse> login(@RequestBody UserLoginRequest req) {
        return ResponseEntity.ok(authService.login(req));
    }

    @PostMapping("/request/approval")
    public ResponseEntity<?> postByGstin(@Valid @RequestBody GstinRequest request) {
        ApprovalResponse res = approvalService.requestApproval(request.getCustomerId(), request.getGstin());
        return ResponseEntity.ok(res);
    }

    @PostMapping("/approvals/approve")
    public ResponseEntity<ApiSuccess> approve(@RequestBody CustomerApprovalRequest req) {
        approvalService.approve(req.getCustomerId());
        return ResponseEntity.ok(new ApiSuccess("APPROVED"));
    }

    @PostMapping("/approvals/reject")
    public ResponseEntity<ApiSuccess> reject(@RequestBody CustomerApprovalRequest req) {
        approvalService.reject(req.getCustomerId());
        return ResponseEntity.ok(new ApiSuccess("REJECTED"));
    }

    @GetMapping("/approvals/status/{approvalId}")
    public ResponseEntity<?> status(@RequestHeader("X-ACCESS-KEY") String key,
                                    @PathVariable Long approvalId) {
//        Long id = Long.parseLong(approvalId);
        return ResponseEntity.ok(approvalService.status(key, approvalId));
    }

    @GetMapping("/approvals/pending")
    public ResponseEntity<List<ApprovalQueueDto>> pending(@RequestHeader("X-ACCESS-KEY") String key) {

        return ResponseEntity.ok(approvalService.pendingForAdmin(key));
    }


    @GetMapping(value="admin-approval/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public SseEmitter stream(@RequestParam String key) {
        User admin = userRepo.findBySseKey(key)
                .orElseThrow(() -> new RuntimeException("Invalid SSE key"));

        if (!admin.getRole().equals("ADMIN"))
            throw new RuntimeException("Access denied");
        return approvalStreamService.subscribe(admin);
    }

    @GetMapping(value="customers/approval-stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public SseEmitter customerStream(@RequestParam String key) {
        User customer = userRepo.findBySseKey(key)
                .orElseThrow(() -> new RuntimeException("Invalid key"));
        return customerApprovalStreamService.subscribe(customer);
    }


}
