package com.backendservice.digital_receipt_system.repositories;

import com.backendservice.digital_receipt_system.entities.RevenueStamp;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface RevenueStampRepository extends JpaRepository<RevenueStamp, Long> {
    List<RevenueStamp> findByReceiptId(Long receiptId);
    Optional<RevenueStamp> findByPayloadHash(String payloadHash);
}