package com.backendservice.digital_receipt_system.schedulers;

import com.backendservice.digital_receipt_system.repositories.ApprovalRepository;
import jakarta.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.Instant;

/**
 * Scheduled job to expire pending approvals.
 * Adds logging around execution and error handling to ensure failures are visible.
 */
@Component
public class ApprovalExpiryScheduler {

    private static final Logger log = LoggerFactory.getLogger(ApprovalExpiryScheduler.class);

    private final ApprovalRepository repo;

    public ApprovalExpiryScheduler(ApprovalRepository repo) {
        this.repo = repo;
        log.debug("ApprovalExpiryScheduler initialized with repo={}", repo != null ? repo.getClass().getSimpleName() : null);
    }

    @Scheduled(fixedRate = 60000) // every 1 minute
    @Transactional
    public void expireRequests() {
        log.info("ApprovalExpiryScheduler.expireRequests triggered at {}", Instant.now());
        try {
            repo.expirePending(Instant.now());
            log.info("ApprovalExpiryScheduler.expireRequests completed successfully");
        } catch (Exception ex) {
            log.error("Error while expiring approvals", ex);
            // swallow or rethrow based on desired scheduler semantics; here we log and allow scheduler to continue
        }
    }
}