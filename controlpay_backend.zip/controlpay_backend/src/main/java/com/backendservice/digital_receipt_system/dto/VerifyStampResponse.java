package com.backendservice.digital_receipt_system.dto;

import java.time.Instant;

public record VerifyStampResponse(boolean valid, Long stampId, String issuer, Instant issuedAt, String payloadHash) {}