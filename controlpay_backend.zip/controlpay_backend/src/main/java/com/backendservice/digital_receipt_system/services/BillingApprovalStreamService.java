package com.backendservice.digital_receipt_system.services;

import com.backendservice.digital_receipt_system.dto.BillingQueueDto;
import com.backendservice.digital_receipt_system.entities.User;
import com.backendservice.digital_receipt_system.repositories.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
@Slf4j
public class BillingApprovalStreamService {

    private final UserRepository userRepo;

    // Active SSE connections
    private final Map<Long, SseEmitter> customerEmitters = new ConcurrentHashMap<>();
    private final Map<Long, SseEmitter> agentEmitters    = new ConcurrentHashMap<>();

    public BillingApprovalStreamService(UserRepository userRepo) {
        this.userRepo = userRepo;
    }

    // Customer subscribes
    public SseEmitter subscribeCustomer(User u) {

        SseEmitter emitter = new SseEmitter(5 * 60 * 1000L);
        customerEmitters.put(u.getId(), emitter);
        emitter.onCompletion(() -> customerEmitters.remove(u.getId()));
        emitter.onTimeout(() -> customerEmitters.remove(u.getId()));
        return emitter;
    }

    // Billing agent subscribes
    public SseEmitter subscribeAgent(User u) {

        SseEmitter emitter = new SseEmitter(0L);
        agentEmitters.put(u.getId(), emitter);
        emitter.onCompletion(() -> agentEmitters.remove(u.getId()));
        emitter.onTimeout(() -> agentEmitters.remove(u.getId()));
        return emitter;
    }

    // Push new carts to agent
    public void notifyAgent(Long agentId, BillingQueueDto dto) {
        SseEmitter emitter = agentEmitters.get(agentId);
        if (emitter != null) try {
            emitter.send(dto);
        } catch (Exception e) {
            agentEmitters.remove(agentId);
        }
    }

    // Push status to customer
    public void notifyCustomer(Long customerId, Long requestId, String status) {
        SseEmitter emitter = customerEmitters.get(customerId);
        if (emitter != null) try {
            emitter.send(Map.of("requestId", requestId, "status", status));
        } catch (Exception e) {
            customerEmitters.remove(customerId);
        }
    }
}
