package com.backendservice.digital_receipt_system.exceptions;

/**
 * Thrown when eKYC verification fails or cannot be completed.
 */
public class EkycVerificationException extends RuntimeException {
    public EkycVerificationException(String message) {
        super(message);
    }

    public EkycVerificationException(String message, Throwable cause) {
        super(message, cause);
    }
}