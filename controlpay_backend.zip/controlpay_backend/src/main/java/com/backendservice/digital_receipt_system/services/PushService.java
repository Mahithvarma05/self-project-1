//package com.backendservice.digital_receipt_system.services;
//
//import com.backendservice.digital_receipt_system.entities.User;
//import com.backendservice.digital_receipt_system.repositories.UserRepository;
//import com.google.firebase.messaging.*;
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//
//@Service
//@Slf4j
//public class PushService {
//
//    private final UserRepository userRepo;
//
//    public PushService(UserRepository userRepo) {
//        this.userRepo = userRepo;
//    }
//
//    public void notifyAdmins(List<Long> adminIds, String title, String message) {
//
//        List<String> tokens = userRepo.findPushTokens(adminIds);
//
//        if (tokens.isEmpty()) return;
//
//        MulticastMessage msg = MulticastMessage.builder()
//                .addAllTokens(tokens)
//                .setNotification(Notification.builder()
//                        .setTitle(title)
//                        .setBody(message)
//                        .build())
//                .build();
//
//        try {
//            FirebaseMessaging.getInstance().sendMulticast(msg);
//        } catch (FirebaseMessagingException e) {
//            throw new RuntimeException(e);
//        }
//    }
//
//    public void notifyCustomer(Long customerId, String title, String message) {
//
//        userRepo.findPushToken(customerId)
//                .ifPresent(token -> {
//                    Message msg = Message.builder()
//                            .setToken(token)
//                            .setNotification(Notification.builder()
//                                    .setTitle(title)
//                                    .setBody(message)
//                                    .build())
//                            .build();
//                    try {
//                        FirebaseMessaging.getInstance().send(msg);
//                    } catch (FirebaseMessagingException e) {
//                        throw new RuntimeException(e);
//                    }
//                });
//    }
//    public void notifyAgents(List<Long> agentIds, String title, String body) {
//
//        List<User> agents = userRepo.findAllById(agentIds);
//
//        agents.stream()
//                .filter(u -> u.getPushToken() != null)
//                .forEach(u -> send(u.getPushToken(), title, body));
//    }
//
//    private void send(String token, String title, String body) {
//        try {
//            Message msg = Message.builder()
//                    .setToken(token)
//                    .setNotification(
//                            Notification.builder()
//                                    .setTitle(title)
//                                    .setBody(body)
//                                    .build()
//                    ).build();
//
//            FirebaseMessaging.getInstance().send(msg);
//
//        } catch (Exception e) {
//            log.error("FCM push failed", e);
//        }
//    }
//}
