//package com.backendservice.digital_receipt_system.services;
//
//import com.backendservice.digital_receipt_system.dto.CreateStampRequest;
//import com.backendservice.digital_receipt_system.dto.VerifyStampResponse;
//import com.backendservice.digital_receipt_system.entities.BillingRequest;
//import com.backendservice.digital_receipt_system.entities.RevenueStamp;
//import com.backendservice.digital_receipt_system.helper.SignatureUtil;
//import com.backendservice.digital_receipt_system.repositories.BillingRequestRepository;
//import com.backendservice.digital_receipt_system.repositories.RevenueStampRepository;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;
//
//import java.nio.charset.StandardCharsets;
//import java.security.PrivateKey;
//import java.security.PublicKey;
//import java.time.Instant;
//import java.util.Map;
//import java.util.Optional;
//
//@Service
//public class RevenueStampService {
//
//    private final RevenueStampRepository repo;
//    private final ObjectMapper mapper;
//    private final PrivateKey signerPrivateKey; // in prod: use KMS
//    private final PublicKey signerPublicKey;
//    private final String issuerId;
//    private final String signatureAlgorithm = "SHA256withRSA";
//    private final BillingRequestRepository billingRequestRepository;;
//
//    public RevenueStampService(RevenueStampRepository repo,
//                               ObjectMapper mapper,
//                               @Value("${revenue-stamp.issuer-id}") String issuerId,
//                               @Value("${revenue-stamp.private-key-pem:}") String privateKeyPem,
//                               @Value("${revenue-stamp.public-key-pem:}") String publicKeyPem, BillingRequestRepository billingRequestRepository) throws Exception {
//        this.repo = repo;
//        this.mapper = mapper;
//        this.issuerId = issuerId;
//        this.billingRequestRepository = billingRequestRepository;
//        if (privateKeyPem == null || privateKeyPem.isBlank()) {
//            this.signerPrivateKey = null; // must use KMS or throw on create
//        } else {
//            this.signerPrivateKey = SignatureUtil.loadPrivateKeyFromPem(privateKeyPem, "RSA");
//        }
//        this.signerPublicKey = (publicKeyPem == null || publicKeyPem.isBlank())
//                ? null
//                : SignatureUtil.loadPublicKeyFromPem(publicKeyPem, "RSA");
//    }
//
//    // canonicalize payload: here we serialize deterministic JSON (using ObjectMapper default ordering is not guaranteed)
//    private String canonicalPayload(Long receiptId, Map<String, Object> metadata, Instant issuedAt) throws Exception {
//        Map<String, Object> payload = Map.of(
//                "receiptId", receiptId,
//                "issuedAt", issuedAt.toString(),
//                "metadata", metadata == null ? Map.of() : metadata);
//        // Using Jackson default may not be strictly canonical; consider canonical JSON library for strictness
//        return mapper.writeValueAsString(payload);
//    }
//
//    private String sha256Hex(byte[] data) throws Exception {
//        java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-256");
//        byte[] dig = md.digest(data);
//        StringBuilder sb = new StringBuilder();
//        for (byte b : dig) sb.append(String.format("%02x", b));
//        return sb.toString();
//    }
//
//    public RevenueStamp createStamp(CreateStampRequest req) throws Exception {
//        if (signerPrivateKey == null) throw new IllegalStateException("No signer private key configured; use KMS in production");
//
//        Instant issuedAt = Instant.now();
//        String payload = canonicalPayload(req.receiptId(), req.metadata(), issuedAt);
//        byte[] payloadBytes = payload.getBytes(StandardCharsets.UTF_8);
//        String payloadHash = sha256Hex(payloadBytes);
//
//        String signature = SignatureUtil.signSha256WithRsa(payloadBytes, signerPrivateKey);
//
//        RevenueStamp stamp = new RevenueStamp();
//        stamp.setReceiptId(req.receiptId());
//        stamp.setIssuer(issuerId);
//        stamp.setIssuedAt(issuedAt);
//        stamp.setPayloadHash(payloadHash);
//        stamp.setSignature(signature);
//        stamp.setSignatureAlgorithm(signatureAlgorithm);
//        stamp.setIssuerCertificate(null);
//        stamp.setMetadata(mapper.writeValueAsString(req.metadata()));
//
//        return repo.save(stamp);
//    }
//
//    @Transactional
//    public RevenueStamp createStampAndAttach(Long billingRequestId, CreateStampRequest req) throws Exception {
//        RevenueStamp stamp = createStamp(req);
//        // attach to billing request
//        BillingRequest br = billingRequestRepository.findById(billingRequestId)
//                .orElseThrow(() -> new RuntimeException("billing request not found"));
//        br.setStamp(stamp);
//        billingRequestRepository.save(br);
//        return stamp;
//    }
//
//    public VerifyStampResponse verifyStamp(String payloadJson, String base64Signature) throws Exception {
//        if (signerPublicKey == null) throw new IllegalStateException("No public key configured");
//
//        byte[] payloadBytes = payloadJson.getBytes(StandardCharsets.UTF_8);
//        String payloadHash = sha256Hex(payloadBytes);
//        boolean ok = SignatureUtil.verifySha256WithRsa(payloadBytes, base64Signature, signerPublicKey);
//        Optional<RevenueStamp> found = repo.findByPayloadHash(payloadHash);
//        if (found.isPresent()) {
//            RevenueStamp s = found.get();
//            boolean match = ok && s.getSignature().equals(base64Signature);
//            return new VerifyStampResponse(match, s.getId(), s.getIssuer(), s.getIssuedAt(), s.getPayloadHash());
//        } else {
//            return new VerifyStampResponse(ok, null, null, null, payloadHash);
//        }
//    }
//}