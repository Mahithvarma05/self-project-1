package com.backendservice.digital_receipt_system.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class ExitParkingRequest {
    
    @NotBlank
    private String areaCode; // From exit QR code scan
}