package com.backendservice.digital_receipt_system.repositories;

import com.backendservice.digital_receipt_system.entities.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByMobileNumber(String mobileNumber);

    boolean existsByMobileNumber(String mobileNumber);

    @Query("SELECT u.pushToken FROM User u WHERE u.id IN :ids AND u.pushToken IS NOT NULL")
    List<String> findPushTokens(List<Long> ids);

    @Query("SELECT u.pushToken FROM User u WHERE u.id = :id")
    Optional<String> findPushToken(Long id);

    Optional<User> findBySseKey(String sseKey);


}
