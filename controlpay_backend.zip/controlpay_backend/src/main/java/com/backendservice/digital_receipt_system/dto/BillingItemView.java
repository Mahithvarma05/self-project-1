package com.backendservice.digital_receipt_system.dto;

import java.math.BigDecimal;

public record BillingItemView(
        String itemName,
        Integer qty,
        BigDecimal price,
        BigDecimal gst,
        BigDecimal lineTotal
) {}
