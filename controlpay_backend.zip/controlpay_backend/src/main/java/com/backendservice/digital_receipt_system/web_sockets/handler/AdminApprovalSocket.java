package com.backendservice.digital_receipt_system.web_sockets.handler;

import com.backendservice.digital_receipt_system.dto.ApprovalQueueDto;
import com.backendservice.digital_receipt_system.entities.User;
import com.backendservice.digital_receipt_system.repositories.UserRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class AdminApprovalSocket extends TextWebSocketHandler {

    private final Map<Long, WebSocketSession> sessions = new ConcurrentHashMap<>();
    private final UserRepository userRepo;
    @Autowired
    ObjectMapper mapper;

    public AdminApprovalSocket(UserRepository userRepo){ this.userRepo=userRepo; }

    @Override
    public void afterConnectionEstablished(WebSocketSession s) {
        String key = UriComponentsBuilder.fromUri(s.getUri()).build()
                        .getQueryParams().getFirst("key");

        User admin = userRepo.findBySseKey(key).orElseThrow();

        if (!admin.getRole().equals("ADMIN")) throw new RuntimeException("Forbidden");

        sessions.put(admin.getId(), s);
    }

    public void push(Long adminId, ApprovalQueueDto dto) {
        send(adminId, dto);
    }

    private void send(Long id, Object o) {
        try {
            WebSocketSession s = sessions.get(id);
            if (s!=null && s.isOpen())
                s.sendMessage(new TextMessage(mapper.writeValueAsString(o)));
        } catch (Exception ignored){}
    }
}
