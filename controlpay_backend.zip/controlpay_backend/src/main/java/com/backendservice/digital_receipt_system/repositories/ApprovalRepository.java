package com.backendservice.digital_receipt_system.repositories;

import com.backendservice.digital_receipt_system.dto.ApprovalQueueDto;
import com.backendservice.digital_receipt_system.entities.ApprovalRequest;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

public interface ApprovalRepository extends JpaRepository<ApprovalRequest, Long> {

    Optional<ApprovalRequest> findByCustomerIdAndStoreGstin(Long customerId, String storeGstin);

    @Modifying
    @Query("""
        UPDATE ApprovalRequest a
        SET a.status = 'EXPIRED'
        WHERE a.status = 'PENDING'
        AND a.expiresAt < :now
    """)
    int expirePending(Instant now);

    @Query("""
    
    SELECT new com.backendservice.digital_receipt_system.dto.ApprovalQueueDto(
        a.id,
        u.name,
        u.mobileNumber,
        a.createdAt,
        a.customerId
    )
    FROM ApprovalRequest a
    JOIN User u ON u.id = a.customerId
    WHERE a.storeGstin = :gstin
      AND a.status = 'PENDING'
    ORDER BY a.createdAt DESC
""")
    List<ApprovalQueueDto> findPendingByStore(String gstin);

    Optional<ApprovalRequest> findTopByCustomerIdAndStoreGstinAndStatusOrderByCreatedAtDesc(
            Long customerId, String storeGstin, String status);

    Optional<ApprovalRequest> findTopByCustomerIdAndStoreGstinOrderByCreatedAtDesc(
            Long customerId, String storeGstin
    );


    @Lock(LockModeType.PESSIMISTIC_WRITE)
    Optional<ApprovalRequest> findByCustomerIdAndStatus(Long customerId, String status);
}
