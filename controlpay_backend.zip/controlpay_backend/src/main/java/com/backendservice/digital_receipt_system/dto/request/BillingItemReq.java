package com.backendservice.digital_receipt_system.dto.request;

public record BillingItemReq(
        Long itemId,
        Integer qty
) {}
