package com.backendservice.digital_receipt_system.web_sockets.handler;

import com.backendservice.digital_receipt_system.entities.User;
import com.backendservice.digital_receipt_system.repositories.UserRepository;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class CustomerBillingSocketHandler extends TextWebSocketHandler {

    private final UserRepository userRepo;

    private final Map<Long, WebSocketSession> sessions = new ConcurrentHashMap<>();

    public CustomerBillingSocketHandler(UserRepository userRepo) {
        this.userRepo = userRepo;
    }

    @Override
    public void afterConnectionEstablished(WebSocketSession session) throws Exception {
        String key = session.getUri().getQuery().split("=")[1];
        User user = userRepo.findBySseKey(key).orElseThrow();
        sessions.put(user.getId(), session);
    }

    public void notifyCustomer(Long customerId, String status) {
        WebSocketSession session = sessions.get(customerId);
        if (session != null && session.isOpen()) {
            try {
                session.sendMessage(new TextMessage(status));
            } catch (Exception e) {
                sessions.remove(customerId);
            }
        }
    }
}
