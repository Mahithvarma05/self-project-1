package com.backendservice.digital_receipt_system.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class WebClientConfig {

    @Value("${ekyc.connect-timeout-ms:5000}")
    private int connectTimeoutMs;

    @Bean(name = "ekycWebClient")
    public WebClient ekycWebClient() {
        // Basic WebClient instance suitable for calling external eKYC endpoints.
        // Customize timeouts, codecs, filters and SSL if required.
        return WebClient.builder()
                .exchangeStrategies(ExchangeStrategies.builder()
                        .codecs(configurer -> configurer.defaultCodecs().maxInMemorySize(16 * 1024 * 1024))
                        .build())
                .build();
    }
}