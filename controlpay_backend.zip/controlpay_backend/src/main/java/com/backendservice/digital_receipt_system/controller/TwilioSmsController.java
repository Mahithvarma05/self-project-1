package com.backendservice.digital_receipt_system.controller;

import com.backendservice.digital_receipt_system.services.TwilioSmsService;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/v1/twilio")
public class TwilioSmsController {

    private final TwilioSmsService twilioSmsService;

    public TwilioSmsController(TwilioSmsService twilioSmsService) {
        this.twilioSmsService = twilioSmsService;
    }

    /**
     * Twilio will POST application/x-www-form-urlencoded with fields including:
     * - From: sender phone number (E.164)
     * - Body: message body
     *
     * Configure Twilio's Messaging webhook to point to this URL.
     */
    @PostMapping(value = "/sms", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    public ResponseEntity<String> receiveSms(@RequestParam Map<String, String> form) {

        String from = form.getOrDefault("From", form.getOrDefault("from", ""));
        String body = form.getOrDefault("Body", form.getOrDefault("body", "")).trim();

        // Optionally validate Twilio signature here (recommended for production).
        // see TwilioSmsService.verifyRequest(...) example.

        String reply = twilioSmsService.processIncomingSms(from, body);

        // TwiML response (XML)
        String twiml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
                + "<Response>\n"
                + "  <Message>" + escapeXml(reply) + "</Message>\n"
                + "</Response>";

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_XML);
        return ResponseEntity.ok().headers(headers).body(twiml);
    }

    private String escapeXml(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&apos;");
    }
}