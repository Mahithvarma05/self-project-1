package com.backendservice.digital_receipt_system.dto.response;

public record CustomerResponse(
        Long id,
        String name,
        String mobileNumber,
        String status,
        String accessKey
) {}
