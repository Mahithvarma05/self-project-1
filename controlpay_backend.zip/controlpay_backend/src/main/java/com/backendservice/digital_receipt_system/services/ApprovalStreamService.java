package com.backendservice.digital_receipt_system.services;

import com.backendservice.digital_receipt_system.dto.ApprovalQueueDto;
import com.backendservice.digital_receipt_system.entities.User;
import com.backendservice.digital_receipt_system.repositories.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class ApprovalStreamService {

    private final UserRepository userRepo;

    private final Map<Long, SseEmitter> emitters = new ConcurrentHashMap<>();

    public ApprovalStreamService(UserRepository userRepo) {
        this.userRepo = userRepo;
    }

    public SseEmitter subscribe(User admin) {

        Long adminId = admin.getId();
        SseEmitter emitter = new SseEmitter(0L);
        emitters.put(adminId, emitter);
        emitter.onCompletion(() -> emitters.remove(adminId));
        emitter.onTimeout(() -> emitters.remove(adminId));
        return emitter;
    }

    public void notifyAdmin(Long adminId, ApprovalQueueDto dto) {
        SseEmitter emitter = emitters.get(adminId);
        if (emitter != null) {
            try {
                emitter.send(dto);
            } catch (Exception ignored) {}
        }
    }
}
