package com.backendservice.digital_receipt_system.controller;


import com.backendservice.digital_receipt_system.dto.ApiError;
import com.backendservice.digital_receipt_system.dto.ApiSuccess;
import com.backendservice.digital_receipt_system.services.PaymentPersistenceService;
import com.backendservice.digital_receipt_system.services.PaymentService;
import jakarta.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.*;

import java.nio.charset.StandardCharsets;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/v1/payments")
public class WebhookController {

    private static final Logger log = LoggerFactory.getLogger(WebhookController.class);

    private final PaymentService paymentService;
    private final PaymentPersistenceService persistenceService;

    public WebhookController(PaymentService paymentService, PaymentPersistenceService persistenceService) {
        this.paymentService = paymentService;
        this.persistenceService = persistenceService;
    }

    /**
     * Razorpay webhook endpoint. Verify signature and persist events.
     */
    @PostMapping("/webhook")
    public ResponseEntity<?> webhook(HttpServletRequest request,
                                     @RequestHeader("X-Razorpay-Signature") String signature) {
        try {
            String body = StreamUtils.copyToString(request.getInputStream(), StandardCharsets.UTF_8);

            if (!paymentService.verifyWebhookSignature(body, signature)) {
                log.warn("Webhook invalid signature");
                return ResponseEntity.badRequest().body(new ApiError("invalid_signature", "Invalid webhook signature"));
            }
            persistenceService.processWebhookEvent(body);
            return ResponseEntity.ok(new ApiSuccess("ok"));

        } catch (Exception e) {
            log.error("Webhook failed", e);
            return ResponseEntity.internalServerError().body(new ApiError("error", "Webhook processing failed"));
        }
    }
}