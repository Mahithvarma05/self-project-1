package com.backendservice.digital_receipt_system.web_sockets.config;

import com.backendservice.digital_receipt_system.web_sockets.handler.AdminApprovalSocket;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.socket.config.annotation.EnableWebSocket;
import org.springframework.web.socket.config.annotation.WebSocketConfigurer;
import org.springframework.web.socket.config.annotation.WebSocketHandlerRegistry;

@Configuration
@EnableWebSocket
public class AdminWsConfig implements WebSocketConfigurer {
    private final AdminApprovalSocket socket;
    public AdminWsConfig(AdminApprovalSocket socket){ this.socket=socket; }

    @Override
    public void registerWebSocketHandlers(WebSocketHandlerRegistry reg) {
        reg.addHandler(socket, "/ws/admin/approvals").setAllowedOrigins("*");
    }
}
