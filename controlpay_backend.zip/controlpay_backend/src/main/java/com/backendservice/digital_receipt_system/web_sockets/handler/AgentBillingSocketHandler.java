package com.backendservice.digital_receipt_system.web_sockets.handler;

import com.backendservice.digital_receipt_system.dto.BillingQueueDto;
import com.backendservice.digital_receipt_system.entities.User;
import com.backendservice.digital_receipt_system.repositories.UserRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class AgentBillingSocketHandler extends TextWebSocketHandler {

    private final UserRepository userRepo;
    private final Map<Long, WebSocketSession> sessions = new ConcurrentHashMap<>();
    @Autowired
    ObjectMapper mapper;

    public AgentBillingSocketHandler(UserRepository userRepo) {
        this.userRepo = userRepo;
    }

    @Override
    public void afterConnectionEstablished(WebSocketSession session) throws Exception {
        String key = session.getUri().getQuery().split("=")[1];
        User agent = userRepo.findBySseKey(key).orElseThrow();
        sessions.put(agent.getId(), session);
    }

    public void notifyAgent(Long agentId, BillingQueueDto dto) {
        WebSocketSession s = sessions.get(agentId);
        if (s != null && s.isOpen()) {
            try {
                s.sendMessage(new TextMessage(mapper.writeValueAsString(dto)));
            } catch (Exception e) {
                sessions.remove(agentId);
            }
        }
    }
}
