package com.backendservice.digital_receipt_system.controller;

import com.backendservice.digital_receipt_system.dto.request.RegisterRequest;
import com.backendservice.digital_receipt_system.dto.response.RegisterResponse;
import com.backendservice.digital_receipt_system.entities.User;
import com.backendservice.digital_receipt_system.services.UserRegistrationService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/**
 * Registration endpoint that accepts optional Aadhaar / PAN for eKYC verification.
 *
 * POST /v1/auth/register
 * Body: RegisterRequest (name, mobile, password, aadhaar?, pan?)
 *
 * Response: RegisterResponse (userId, name, role, accessKey, message)
 */
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/v1/auth")
@Validated
public class RegistrationController {

    private final UserRegistrationService registrationService;

    public RegistrationController(UserRegistrationService registrationService) {
        this.registrationService = registrationService;
    }

    @PostMapping("/register")
    public ResponseEntity<RegisterResponse> register(@Valid @RequestBody RegisterRequest req) {
        try {
            User u = registrationService.register(
                    req.name(),
                    req.mobile(),
                    req.password(),
                    req.aadhaar(),
                    req.pan()
            );

            RegisterResponse res = new RegisterResponse(
                    u.getId(),
                    u.getName(),
                    u.getRole(),
                    u.getSseKey(),
                    "REGISTERED"
            );
            return ResponseEntity.ok(res);

        } catch (Exception ex) {
            // Map registration/eKYC failures to 400 Bad Request with message.
            // You may want to replace with a ControllerAdvice for richer error handling.
            RegisterResponse err = new RegisterResponse(
                    null,
                    null,
                    null,
                    null,
                    ex.getMessage() == null ? "REGISTRATION_FAILED" : ex.getMessage()
            );
            return ResponseEntity.badRequest().body(err);
        }
    }
}