package com.backendservice.digital_receipt_system.dto.request;

import lombok.Data;

@Data
public class UserLoginRequest {
    private String mobileNumber;
    private String password;
}
