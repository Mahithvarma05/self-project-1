package com.backendservice.digital_receipt_system.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

@Data
public class SaveVehicleRequest {
    
    @NotBlank
    @Pattern(regexp = "^(TWO_WHEELER|FOUR_WHEELER|HEAVY_VEHICLE)$", 
             message = "Vehicle type must be TWO_WHEELER, FOUR_WHEELER, or HEAVY_VEHICLE")
    private String vehicleType;
    
    @NotBlank
    @Pattern(regexp = "^[A-Z]{2}[0-9]{1,2}[A-Z]{1,2}[0-9]{4}$", 
             message = "Invalid number plate format")
    private String numberPlate;
    
    private String brand;
    private String model;
    private String color;
    private Boolean isDefault = false;
}