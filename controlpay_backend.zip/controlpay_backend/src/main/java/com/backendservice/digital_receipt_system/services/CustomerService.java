package com.backendservice.digital_receipt_system.services;

import com.backendservice.digital_receipt_system.dto.request.CreateCustomerRequest;
import com.backendservice.digital_receipt_system.dto.response.CustomerResponse;
import com.backendservice.digital_receipt_system.entities.User;
import com.backendservice.digital_receipt_system.repositories.UserRepository;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

@Service
public class CustomerService {

    private final UserRepository userRepo;

    public CustomerService(UserRepository userRepo) {
        this.userRepo = userRepo;
    }

    @Transactional
    public CustomerResponse createOrGet(CreateCustomerRequest req) {

        return userRepo.findByMobileNumber(req.getMobileNumber())
                .map(u -> new CustomerResponse(
                        u.getId(), u.getName(), u.getMobileNumber(), "EXISTING", u.getSseKey()))
                .orElseGet(() -> {

                    User u = new User();
                    u.setName(req.getName());
                    u.setMobileNumber(req.getMobileNumber());
                    u.setRole("CUSTOMER");
                    u.setPassword(null);
                    u.setActive(true);
                    u.setSseKey(UUID.randomUUID().toString().replace("-", ""));

                    try {
                        User saved = userRepo.save(u);
                        return new CustomerResponse(
                                saved.getId(), saved.getName(), saved.getMobileNumber(), "CREATED", saved.getSseKey());
                    } catch (DataIntegrityViolationException e) {
                        User existing = userRepo.findByMobileNumber(req.getMobileNumber()).get();
                        return new CustomerResponse(
                                existing.getId(), existing.getName(), existing.getMobileNumber(), "EXISTING", existing.getSseKey());
                    }
                });
    }
}

