package com.backendservice.digital_receipt_system.services;

import com.backendservice.digital_receipt_system.exceptions.EkycVerificationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.Map;

/**
 * Generic eKYC client that calls configured endpoints (e.g. API Setu).
 *
 * You MUST configure:
 *  - ekyc.enabled: true/false
 *  - ekyc.aadhaar.endpoint
 *  - ekyc.pan.endpoint
 *  - ekyc.api-key (or other header) if required by provider
 *
 * Adjust request body / headers and response parsing to match the exact provider contract.
 */
@Service
public class EkycService {

    private static final Logger log = LoggerFactory.getLogger(EkycService.class);

    private final WebClient client;
    private final boolean enabled;
    private final String aadhaarEndpoint;
    private final String panEndpoint;
    private final String apiKeyHeaderName;
    private final String apiKeyValue;
    private final Duration requestTimeout;

    public EkycService(
            @Qualifier("ekycWebClient") WebClient client,
            @Value("${ekyc.enabled:false}") boolean enabled,
            @Value("${ekyc.aadhaar.endpoint:}") String aadhaarEndpoint,
            @Value("${ekyc.pan.endpoint:}") String panEndpoint,
            @Value("${ekyc.api-key-header-name:X-API-KEY}") String apiKeyHeaderName,
            @Value("${ekyc.api-key:}") String apiKeyValue,
            @Value("${ekyc.request-timeout-seconds:8}") int timeoutSeconds
    ) {
        this.client = client;
        this.enabled = enabled;
        this.aadhaarEndpoint = aadhaarEndpoint;
        this.panEndpoint = panEndpoint;
        this.apiKeyHeaderName = apiKeyHeaderName;
        this.apiKeyValue = apiKeyValue;
        this.requestTimeout = Duration.ofSeconds(timeoutSeconds);
    }

    public boolean isEnabled() {
        return enabled;
    }

    /**
     * Verify Aadhaar number against external provider.
     * Returns true if verification succeeded.
     *
     * NOTE: adapt payload/body/headers to match provider (API Setu) specification.
     */
    public boolean verifyAadhaar(String aadhaarNumber, String name) {
        if (!enabled) {
            log.debug("eKYC disabled - skipping Aadhaar verification");
            return true;
        }
        if (!StringUtils.hasText(aadhaarEndpoint)) {
            throw new EkycVerificationException("Aadhaar endpoint not configured");
        }
        try {
            // Mask for logs
            String masked = maskNumber(aadhaarNumber);
            log.debug("Calling Aadhaar verification endpoint for {}", masked);

            // Example payload; adapt to provider. Many providers expect JSON with aadhaar and optionally name/dob.
            Map<String, Object> body = Map.of(
                    "aadhaar", aadhaarNumber,
                    "name", name
            );

            Map resp = client.post()
                    .uri(aadhaarEndpoint)
                    .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                    .headers(headers -> {
                        if (StringUtils.hasText(apiKeyValue)) {
                            headers.add(apiKeyHeaderName, apiKeyValue);
                        }
                    })
                    .bodyValue(body)
                    .retrieve()
                    .bodyToMono(Map.class)
                    .timeout(requestTimeout)
                    .onErrorMap(ex -> new EkycVerificationException("Failed to call Aadhaar verification", ex))
                    .block();

            // Basic provider-agnostic verification check:
            // - success if 'verified'==true OR 'status'=='SUCCESS' OR 'result'=='MATCH' etc.
            if (resp == null) {
                throw new EkycVerificationException("Empty response from Aadhaar provider");
            }
            if (Boolean.TRUE.equals(resp.get("verified"))) return true;
            Object status = resp.get("status");
            if (status instanceof String) {
                String s = ((String) status).toLowerCase();
                if (s.contains("success") || s.contains("verified") || s.contains("match")) return true;
            }
            Object result = resp.get("result");
            if (result instanceof String) {
                String r = ((String) result).toLowerCase();
                if (r.contains("match") || r.contains("verified")) return true;
            }

            // Not recognised as success - log minimal details and return false
            log.warn("Aadhaar verification not successful for {}. providerResponseKeys={}", masked, resp.keySet());
            return false;
        } catch (EkycVerificationException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new EkycVerificationException("Aadhaar verification failed", ex);
        }
    }

    /**
     * Verify PAN number against external provider.
     */
    public boolean verifyPan(String panNumber, String name) {
        if (!enabled) {
            log.debug("eKYC disabled - skipping PAN verification");
            return true;
        }
        if (!StringUtils.hasText(panEndpoint)) {
            throw new EkycVerificationException("PAN endpoint not configured");
        }
        try {
            String masked = maskPan(panNumber);
            log.debug("Calling PAN verification endpoint for {}", masked);

            Map<String, Object> body = Map.of(
                    "pan", panNumber,
                    "name", name
            );

            Map resp = client.post()
                    .uri(panEndpoint)
                    .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                    .headers(headers -> {
                        if (StringUtils.hasText(apiKeyValue)) {
                            headers.add(apiKeyHeaderName, apiKeyValue);
                        }
                    })
                    .bodyValue(body)
                    .retrieve()
                    .bodyToMono(Map.class)
                    .timeout(requestTimeout)
                    .onErrorMap(ex -> new EkycVerificationException("Failed to call PAN verification", ex))
                    .block();

            if (resp == null) {
                throw new EkycVerificationException("Empty response from PAN provider");
            }
            if (Boolean.TRUE.equals(resp.get("verified"))) return true;
            Object status = resp.get("status");
            if (status instanceof String) {
                String s = ((String) status).toLowerCase();
                if (s.contains("success") || s.contains("verified") || s.contains("match")) return true;
            }
            Object result = resp.get("result");
            if (result instanceof String) {
                String r = ((String) result).toLowerCase();
                if (r.contains("match") || r.contains("verified")) return true;
            }

            log.warn("PAN verification not successful for {}. providerResponseKeys={}", masked, resp.keySet());
            return false;
        } catch (EkycVerificationException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new EkycVerificationException("PAN verification failed", ex);
        }
    }

    private String maskNumber(String s) {
        if (s == null) return null;
        String digits = s.replaceAll("\\D", "");
        if (digits.length() <= 4) return "****";
        return "****" + digits.substring(digits.length() - 4);
    }

    private String maskPan(String pan) {
        if (pan == null) return null;
        if (pan.length() <= 4) return "****";
        return "****" + pan.substring(pan.length() - 4);
    }
}