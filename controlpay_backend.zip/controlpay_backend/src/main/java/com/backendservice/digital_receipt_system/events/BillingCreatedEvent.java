package com.backendservice.digital_receipt_system.events;

import com.backendservice.digital_receipt_system.dto.BillingItemView;

import java.math.BigDecimal;
import java.util.List;

public record BillingCreatedEvent(
        Long requestId,
        Long customerId,
        String customerName,
        String customerMobile,
        BigDecimal grandTotal,
        List<BillingItemView> items,
        List<Long> agentIds,
        String gstin
) {}