package com.backendservice.digital_receipt_system.enums;

public enum PaymentMode {
    UPI, CARD, NETBANKING, WALLET, CASH
}
