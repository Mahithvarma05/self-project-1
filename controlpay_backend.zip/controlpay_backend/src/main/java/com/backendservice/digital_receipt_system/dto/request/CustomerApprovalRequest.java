package com.backendservice.digital_receipt_system.dto.request;

import lombok.Data;

@Data
public class CustomerApprovalRequest {
    private Long customerId;
}
