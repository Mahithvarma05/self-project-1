package com.backendservice.digital_receipt_system.entities;

import jakarta.persistence.*;
import java.time.Instant;
import java.util.Map;

@Entity
@Table(name = "revenue_stamp")
public class RevenueStamp {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long receiptId;

    private String issuer;

    private Instant issuedAt;

    private String payloadHash;

    @Lob
    private String signature; // base64

    private String signatureAlgorithm;

    @Lob
    private String issuerCertificate; // PEM string (optional)

    @Column(columnDefinition = "jsonb")
    private String metadata; // JSON string

    private Instant createdAt = Instant.now();

    // getters/setters
    // (for brevity, generate via Lombok or your IDE in real project)
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getReceiptId() { return receiptId; }
    public void setReceiptId(Long receiptId) { this.receiptId = receiptId; }
    public String getIssuer() { return issuer; }
    public void setIssuer(String issuer) { this.issuer = issuer; }
    public Instant getIssuedAt() { return issuedAt; }
    public void setIssuedAt(Instant issuedAt) { this.issuedAt = issuedAt; }
    public String getPayloadHash() { return payloadHash; }
    public void setPayloadHash(String payloadHash) { this.payloadHash = payloadHash; }
    public String getSignature() { return signature; }
    public void setSignature(String signature) { this.signature = signature; }
    public String getSignatureAlgorithm() { return signatureAlgorithm; }
    public void setSignatureAlgorithm(String signatureAlgorithm) { this.signatureAlgorithm = signatureAlgorithm; }
    public String getIssuerCertificate() { return issuerCertificate; }
    public void setIssuerCertificate(String issuerCertificate) { this.issuerCertificate = issuerCertificate; }
    public String getMetadata() { return metadata; }
    public void setMetadata(String metadata) { this.metadata = metadata; }
    public Instant getCreatedAt() { return createdAt; }
    public void setCreatedAt(Instant createdAt) { this.createdAt = createdAt; }
}