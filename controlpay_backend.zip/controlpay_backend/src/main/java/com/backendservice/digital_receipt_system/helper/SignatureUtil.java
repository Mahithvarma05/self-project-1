//package com.backendservice.digital_receipt_system.helper;
//
//import java.nio.charset.StandardCharsets;
//import java.security.*;
//import java.security.spec.*;
//import java.util.Base64;
//
//public class SignatureUtil {
//
//    // Example: sign with ECDSA (secp256r1) or RSA. Here: SHA256withRSA as example.
//    public static String signSha256WithRsa(byte[] data, PrivateKey privateKey) throws GeneralSecurityException {
//        Signature sig = Signature.getInstance("SHA256withRSA");
//        sig.initSign(privateKey);
//        sig.update(data);
//        byte[] signed = sig.sign();
//        return Base64.getEncoder().encodeToString(signed);
//    }
//
//    public static boolean verifySha256WithRsa(byte[] data, String base64Signature, PublicKey publicKey) throws GeneralSecurityException {
//        Signature sig = Signature.getInstance("SHA256withRSA");
//        sig.initVerify(publicKey);
//        sig.update(data);
//        byte[] signatureBytes = Base64.getDecoder().decode(base64Signature);
//        return sig.verify(signatureBytes);
//    }
//
//    // Helper to load RSA private key from PKCS#8 PEM (for dev only; use KMS in prod)
//    public static PrivateKey loadPrivateKeyFromPem(String pem, String algorithm) throws GeneralSecurityException {
//        String cleaned = pem.replaceAll("-----BEGIN (.*)-----", "")
//                .replaceAll("-----END (.*)-----", "")
//                .replaceAll("\\s+", "");
//        byte[] keyBytes = Base64.getDecoder().decode(cleaned);
//        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(keyBytes);
//        KeyFactory kf = KeyFactory.getInstance(algorithm);
//        return kf.generatePrivate(keySpec);
//    }
//
//    public static PublicKey loadPublicKeyFromPem(String pem, String algorithm) throws GeneralSecurityException {
//        String cleaned = pem.replaceAll("-----BEGIN (.*)-----", "")
//                .replaceAll("-----END (.*)-----", "")
//                .replaceAll("\\s+", "");
//        byte[] keyBytes = Base64.getDecoder().decode(cleaned);
//        X509EncodedKeySpec spec = new X509EncodedKeySpec(keyBytes);
//        KeyFactory kf = KeyFactory.getInstance(algorithm);
//        return kf.generatePublic(spec);
//    }
//}