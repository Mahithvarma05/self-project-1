package com.backendservice.digital_receipt_system.repositories;

import com.backendservice.digital_receipt_system.entities.UserStoreMap;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface UserStoreMapRepository extends JpaRepository<UserStoreMap, Long> {

    @Query("SELECT u.storeGstin FROM UserStoreMap u WHERE u.userId = :userId")
    Optional<String> findStoreForUser(Long userId);

    @Query("""
    SELECT u.id FROM User u
    JOIN UserStoreMap m ON u.id = m.userId
    WHERE m.storeGstin = :gstin AND u.role = 'ADMIN'
""")
    List<Long> findAdminsForStore(String gstin);

    @Query("""
    SELECT u.id FROM User u
    JOIN UserStoreMap m ON u.id = m.userId
    WHERE m.storeGstin = :gstin AND u.role = 'BILLING_AGENT'
""")
    List<Long> findBillingAgentsForStore(@Param("gstin") String gstin);
}
