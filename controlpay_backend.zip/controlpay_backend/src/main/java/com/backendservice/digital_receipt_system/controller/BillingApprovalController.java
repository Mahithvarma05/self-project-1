package com.backendservice.digital_receipt_system.controller;

import com.backendservice.digital_receipt_system.dto.ApiSuccess;
import com.backendservice.digital_receipt_system.dto.BillingQueueDto;
import com.backendservice.digital_receipt_system.dto.request.BillingRequestDto;
import com.backendservice.digital_receipt_system.entities.User;
import com.backendservice.digital_receipt_system.repositories.UserRepository;
import com.backendservice.digital_receipt_system.services.BillingApprovalService;
import com.backendservice.digital_receipt_system.services.BillingApprovalStreamService;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.util.List;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/v1/billing")
public class BillingApprovalController {

    private final BillingApprovalService service;
    private final BillingApprovalStreamService streamService;
    private final UserRepository userRepo;

    public BillingApprovalController(BillingApprovalService service, BillingApprovalStreamService streamService, UserRepository userRepo) {
        this.service = service;
        this.streamService = streamService;
        this.userRepo = userRepo;
    }

    // Customer sends cart
    @PostMapping("/request")
    public ResponseEntity<?> create(@RequestHeader("X-ACCESS-KEY") String key,
                                    @RequestBody BillingRequestDto dto) {
        return ResponseEntity.ok(service.requestBillingApproval(dto, key));
    }

    // Agent pending
    @GetMapping("/pending")
    public List<BillingQueueDto> pending(@RequestHeader("X-ACCESS-KEY") String key) {
        return service.pendingForAgent(key);
    }

    // Approve
    @PostMapping("/approve/{id}")
    public ResponseEntity<ApiSuccess> approve(@PathVariable Long id) {
        service.approve(id);
        return ResponseEntity.ok(new ApiSuccess("APPROVED"));

    }

    // Reject
    @PostMapping("/reject/{id}")
    public ResponseEntity<ApiSuccess> reject(@PathVariable Long id) {
        service.reject(id);
        return ResponseEntity.ok(new ApiSuccess("REJECTED"));
    }

    // Customer stream
    @GetMapping(value="/stream", produces= MediaType.TEXT_EVENT_STREAM_VALUE)
    public SseEmitter stream(@RequestParam String key) {
        User u = userRepo.findBySseKey(key)
                .orElseThrow(() -> new RuntimeException("Invalid key"));
        return streamService.subscribeCustomer(u);
    }

    // Billing agent stream
    @GetMapping(value = "/agent-stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public SseEmitter agentStream(@RequestParam String key) {
        User u = userRepo.findBySseKey(key)
                .orElseThrow(() -> new RuntimeException("Invalid key"));

        if (!u.getRole().equals("BILLING_AGENT"))
            throw new RuntimeException("Access denied");
        return streamService.subscribeAgent(u);
    }

    @GetMapping("/approvals/status/{approvalId}")
    public ResponseEntity<?> status(@RequestHeader("X-ACCESS-KEY") String key,
                                    @PathVariable Long approvalId) {
        return ResponseEntity.ok(service.billingStatus(key, approvalId));
    }
}
