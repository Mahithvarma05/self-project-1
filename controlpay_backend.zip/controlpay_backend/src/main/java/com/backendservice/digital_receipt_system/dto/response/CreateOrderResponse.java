package com.backendservice.digital_receipt_system.dto.response;

import org.json.JSONObject;

public class CreateOrderResponse {
    private String id;
    private Long amount;
    private String currency;
    private String receipt;
    private Long amountPaid;
    private Long amountDue;
    private JSONObject raw; // raw order object for extra fields

    public CreateOrderResponse() {}

    public CreateOrderResponse(JSONObject order) {
        this.id = order.optString("id");
        this.amount = convertPaiseToRupee(order.optLong("amount"));
        this.currency = order.optString("currency");
        this.receipt = order.optString("receipt");
        this.amountPaid = convertPaiseToRupee(order.optLong("amount_paid", 0));
        this.amountDue = convertPaiseToRupee(order.optLong("amount_due", 0));
        this.raw = order;
    }

    // getters / setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public Long getAmount() { return amount; }
    public void setAmount(Long amount) { this.amount = amount; }

    public String getCurrency() { return currency; }
    public void setCurrency(String currency) { this.currency = currency; }

    public String getReceipt() { return receipt; }
    public void setReceipt(String receipt) { this.receipt = receipt; }

    public Long getAmountPaid() { return amountPaid; }
    public void setAmountPaid(Long amountPaid) { this.amountPaid = amountPaid; }

    public Long getAmountDue() { return amountDue; }
    public void setAmountDue(Long amountDue) { this.amountDue = amountDue; }

    public JSONObject getRaw() { return raw; }
    public void setRaw(JSONObject raw) { this.raw = raw; }

    private Long convertPaiseToRupee(Long amount) {
        return (amount != null) ? amount / 100 : 0L;
    }
}