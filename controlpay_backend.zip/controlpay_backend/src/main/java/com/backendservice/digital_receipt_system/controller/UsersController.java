package com.backendservice.digital_receipt_system.controller;

import com.backendservice.digital_receipt_system.dto.request.PushTokenRequest;
import com.backendservice.digital_receipt_system.entities.User;
import com.backendservice.digital_receipt_system.repositories.UserRepository;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/v1/users")
@Validated
public class UsersController {

    private final UserRepository userRepo;

    public UsersController(UserRepository userRepo) {
        this.userRepo = userRepo;
    }

    @PostMapping("/push-token")
    public ResponseEntity<?> saveToken(
            @RequestHeader("X-ACCESS-KEY") String key,
            @Valid @RequestBody PushTokenRequest req) {

        User user = userRepo.findBySseKey(key)
                .orElseThrow(() -> new RuntimeException("Invalid access key"));

        user.setPushToken(req.getToken());
        userRepo.save(user);

        return ResponseEntity.ok().build();
    }
}
