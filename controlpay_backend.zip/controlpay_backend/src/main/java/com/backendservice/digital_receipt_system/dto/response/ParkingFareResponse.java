package com.backendservice.digital_receipt_system.dto.response;

import java.math.BigDecimal;
import java.time.Instant;

public record ParkingFareResponse(
    Long sessionId,
    String sessionCode,
    Instant startTime,
    Instant exitTime,
    Long durationMinutes,
    Long durationHours,
    Integer hourlyRate,
    BigDecimal totalAmount,
    String status
) {}