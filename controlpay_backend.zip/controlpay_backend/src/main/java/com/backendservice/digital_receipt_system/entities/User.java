package com.backendservice.digital_receipt_system.entities;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "users")
@Data
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String mobileNumber;
    private String password;
    private String role;
    private String pushToken;
    private Boolean active;
    @Column(name = "sse_key", unique = true, length = 64)
    private String sseKey;

}
