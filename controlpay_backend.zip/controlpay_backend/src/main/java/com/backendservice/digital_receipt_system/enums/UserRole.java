package com.backendservice.digital_receipt_system.enums;

public enum UserRole {
    ROLE_CONSUMER,
    ROLE_MERCHANT_ADMIN,
    ROLE_STOREKEEPER
}
