package com.backendservice.digital_receipt_system.repositories;

import com.backendservice.digital_receipt_system.dto.BillingItemView;
import com.backendservice.digital_receipt_system.entities.BillingRequestItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface BillingRequestItemRepository
        extends JpaRepository<BillingRequestItem, Long> {

    @Query("""
       select new com.backendservice.digital_receipt_system.dto.BillingItemView(
           i.itemName, i.qty, i.price, i.gstPercentage, i.lineTotal
       )
       from BillingRequestItem i
       where i.request.id = :requestId
    """)
    List<BillingItemView> findViewsByRequest(@Param("requestId") Long requestId);


}
