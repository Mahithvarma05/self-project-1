package com.backendservice.digital_receipt_system.web_sockets.config;

import com.backendservice.digital_receipt_system.web_sockets.handler.AgentBillingSocketHandler;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.socket.config.annotation.EnableWebSocket;
import org.springframework.web.socket.config.annotation.WebSocketConfigurer;
import org.springframework.web.socket.config.annotation.WebSocketHandlerRegistry;

@Configuration
@EnableWebSocket
public class AgentBillingSocketConfig implements WebSocketConfigurer {

    private final AgentBillingSocketHandler handler;

    public AgentBillingSocketConfig(AgentBillingSocketHandler handler) {
        this.handler = handler;
    }

    @Override
    public void registerWebSocketHandlers(WebSocketHandlerRegistry registry) {
        registry.addHandler(handler, "/ws/agent/billing").setAllowedOrigins("*");
    }
}
