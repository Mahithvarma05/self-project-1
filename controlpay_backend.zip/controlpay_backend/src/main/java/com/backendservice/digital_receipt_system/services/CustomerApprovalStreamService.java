package com.backendservice.digital_receipt_system.services;

import com.backendservice.digital_receipt_system.entities.User;
import com.backendservice.digital_receipt_system.repositories.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class CustomerApprovalStreamService {

    private final UserRepository userRepo;

    private final Map<Long, SseEmitter> emitters = new ConcurrentHashMap<>();

    public CustomerApprovalStreamService(UserRepository userRepo) {
        this.userRepo = userRepo;
    }

    public SseEmitter subscribe(User customer) {

        Long customerId = customer.getId();

        SseEmitter emitter = new SseEmitter(5 * 60 * 1000L);
        emitters.put(customerId, emitter);
        emitter.onCompletion(() -> emitters.remove(customerId));
        emitter.onTimeout(() -> emitters.remove(customerId));
        return emitter;
    }

    public void notifyCustomer(Long customerId, String status) {
        SseEmitter emitter = emitters.get(customerId);
        if (emitter != null) {
            try {
                emitter.send(status);
            } catch (Exception ignored) {}
        }
    }
}
