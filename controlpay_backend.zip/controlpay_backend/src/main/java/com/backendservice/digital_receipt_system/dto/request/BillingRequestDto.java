package com.backendservice.digital_receipt_system.dto.request;

import java.util.List;

public record BillingRequestDto(
        String gstin,
        List<BillingItemReq> items
) {}
