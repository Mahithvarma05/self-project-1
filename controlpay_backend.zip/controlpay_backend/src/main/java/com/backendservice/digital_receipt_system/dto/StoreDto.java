package com.backendservice.digital_receipt_system.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class StoreDto {
    private Long id;
    private String gstin;
    private String storeName;
    private String ownerName;
    @Email(message = "invalid email")
    private String email;
    @Pattern(regexp = "^[0-9]{10,15}$", message = "invalid phone number")
    private String phoneNumber;
    private String address;
    private String city;
    private String state;
    private String pincode;
    private String storeType;
    private Boolean isActive;
    private Instant createdAt;
    private Instant updatedAt;
}