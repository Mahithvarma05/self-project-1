package com.backendservice.digital_receipt_system.entities;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.Objects;

/**
 * BillingRequest entity.
 * Includes a nullable relation to RevenueStamp via the stamp_id foreign key.
 */
@Entity
@Table(name = "billing_request")
public class BillingRequest {

    public enum Status {
        PENDING,
        APPROVED,
        REJECTED,
        EXPIRED
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "customer_id", nullable = false)
    private Long customerId;

    @Column(name = "gstin", length = 64, nullable = false)
    private String gstin;

    @Column(name = "total_amount", precision = 19, scale = 4)
    private BigDecimal totalAmount;

    @Column(name = "gst_amount", precision = 19, scale = 4)
    private BigDecimal gstAmount;

    @Column(name = "grand_total", precision = 19, scale = 4)
    private BigDecimal grandTotal;

    @Column(name = "expires_at")
    private Instant expiresAt;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", length = 32)
    private Status status;

    @Column(name = "created_at", updatable = false)
    private Instant createdAt = Instant.now();

    @Column(name = "updated_at")
    private Instant updatedAt;

    /**
     * New: relation to revenue_stamp table.
     * This creates the stamp_id FK column in billing_request.
     * The relationship is optional (nullable): a billing request may not yet have a stamp.
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "stamp_id", referencedColumnName = "id", foreignKey = @ForeignKey(name = "fk_billing_request_stamp"))
    private RevenueStamp stamp;

    public BillingRequest() {}

    // Getters and setters

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getCustomerId() { return customerId; }
    public void setCustomerId(Long customerId) { this.customerId = customerId; }

    public String getGstin() { return gstin; }
    public void setGstin(String gstin) { this.gstin = gstin; }

    public BigDecimal getTotalAmount() { return totalAmount; }
    public void setTotalAmount(BigDecimal totalAmount) { this.totalAmount = totalAmount; }

    public BigDecimal getGstAmount() { return gstAmount; }
    public void setGstAmount(BigDecimal gstAmount) { this.gstAmount = gstAmount; }

    public BigDecimal getGrandTotal() { return grandTotal; }
    public void setGrandTotal(BigDecimal grandTotal) { this.grandTotal = grandTotal; }

    public Instant getExpiresAt() { return expiresAt; }
    public void setExpiresAt(Instant expiresAt) { this.expiresAt = expiresAt; }

    public Status getStatus() { return status; }
    public void setStatus(Status status) { this.status = status; }

    public Instant getCreatedAt() { return createdAt; }
    public void setCreatedAt(Instant createdAt) { this.createdAt = createdAt; }

    public Instant getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(Instant updatedAt) { this.updatedAt = updatedAt; }

    public RevenueStamp getStamp() { return stamp; }
    public void setStamp(RevenueStamp stamp) { this.stamp = stamp; }

    /**
     * Convenience getter for stamp id (avoids initializing lazy relation in some cases).
     * Returns null if no stamp attached.
     */
    @Transient
    public Long getStampId() {
        return stamp != null ? stamp.getId() : null;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof BillingRequest)) return false;
        BillingRequest that = (BillingRequest) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "BillingRequest{" +
                "id=" + id +
                ", customerId=" + customerId +
                ", gstin='" + gstin + '\'' +
                ", grandTotal=" + grandTotal +
                ", status=" + status +
                ", stampId=" + getStampId() +
                '}';
    }
}