package com.backendservice.digital_receipt_system.controller;

import com.backendservice.digital_receipt_system.dto.ApiSuccess;
import com.backendservice.digital_receipt_system.dto.request.SaveVehicleRequest;
import com.backendservice.digital_receipt_system.dto.response.VehicleResponse;
import com.backendservice.digital_receipt_system.entities.User;
import com.backendservice.digital_receipt_system.repositories.UserRepository;
import com.backendservice.digital_receipt_system.services.VehicleService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/vehicles")
@RequiredArgsConstructor
public class VehicleController {
    
    private final VehicleService vehicleService;
    private final UserRepository userRepo;
    
    @PostMapping
    public ResponseEntity<VehicleResponse> saveVehicle(
            @RequestHeader("X-ACCESS-KEY") String key,
            @Valid @RequestBody SaveVehicleRequest request) {
        
        User user = userRepo.findBySseKey(key)
            .orElseThrow(() -> new RuntimeException("Invalid access key"));
        
        VehicleResponse response = vehicleService.saveVehicle(user.getId(), request);
        return ResponseEntity.ok(response);
    }
    
    @GetMapping
    public ResponseEntity<List<VehicleResponse>> getMyVehicles(
            @RequestHeader("X-ACCESS-KEY") String key) {
        
        User user = userRepo.findBySseKey(key)
            .orElseThrow(() -> new RuntimeException("Invalid access key"));
        
        List<VehicleResponse> vehicles = vehicleService.getUserVehicles(user.getId());
        return ResponseEntity.ok(vehicles);
    }
    
    @DeleteMapping("/{vehicleId}")
    public ResponseEntity<ApiSuccess> deleteVehicle(
            @RequestHeader("X-ACCESS-KEY") String key,
            @PathVariable Long vehicleId) {
        
        User user = userRepo.findBySseKey(key)
            .orElseThrow(() -> new RuntimeException("Invalid access key"));
        
        vehicleService.deleteVehicle(user.getId(), vehicleId);
        return ResponseEntity.ok(new ApiSuccess("Vehicle deleted successfully"));
    }
    
    @PutMapping("/{vehicleId}/set-default")
    public ResponseEntity<VehicleResponse> setDefaultVehicle(
            @RequestHeader("X-ACCESS-KEY") String key,
            @PathVariable Long vehicleId) {
        
        User user = userRepo.findBySseKey(key)
            .orElseThrow(() -> new RuntimeException("Invalid access key"));
        
        VehicleResponse response = vehicleService.setDefaultVehicle(user.getId(), vehicleId);
        return ResponseEntity.ok(response);
    }
}